import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { BrandBanner } from './components/BrandBanner';
import { CategoryGrid } from './components/CategoryGrid';
import { ProductGrid } from './components/ProductGrid';
import { PromoBanner } from './components/PromoBanner';
import { FeatureLacesGrid } from './components/FeatureLacesGrid';
import { NewsSection } from './components/NewsSection';
import { PartnershipsBanner } from './components/PartnershipsBanner';
import { Footer } from './components/Footer';

// Modals & Drawers
import { SearchBarModal } from './components/SearchBarModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { LoginModal } from './components/LoginModal';
import { AdminPortal } from './components/AdminPortal';
import { CustomLaceModal } from './components/CustomLaceModal';
import { TrackOrderModal } from './components/TrackOrderModal';

import { ProductPage } from './components/ProductPage';

function MainAppContent() {
  const { toastMessage, selectedProductPage } = useApp();

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-900 font-sans antialiased selection:bg-lime-400 selection:text-slate-950">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-950 text-white px-5 py-3 rounded-2xl shadow-2xl border border-lime-400 flex items-center gap-3 animate-in fade-in slide-in-from-bottom-4">
          <span className="w-2.5 h-2.5 rounded-full bg-lime-400 animate-pulse" />
          <p className="text-xs font-bold">{toastMessage}</p>
        </div>
      )}

      {/* Header Bar */}
      <Header />

      {/* Main Content Sections or Amazon Product Page */}
      {selectedProductPage ? (
        <ProductPage />
      ) : (
        <main className="flex-1">
          {/* Hero Section matching Screenshot 1 */}
          <Hero />

          {/* Category Feature Cards */}
          <CategoryGrid />

          {/* Best Sellers Product Grid */}
          <ProductGrid title="BEST SELLERS" id="best-sellers-section" filterType="bestseller" />

          {/* News & Sneaker Guides Section */}
          <NewsSection />
        </main>
      )}

      {/* Footer matching Screenshot 3 */}
      <Footer />

      {/* Modals & Overlays */}
      <SearchBarModal />
      <ProductDetailModal />
      <CartDrawer />
      <LoginModal />
      <AdminPortal />
      <CustomLaceModal />
      <TrackOrderModal />

    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
