import { Product, SiteConfig, NewsArticle, CategoryItem } from '../types';

export const INITIAL_SITE_CONFIG: SiteConfig = {
  heroTitle: 'LEVEL UP YOUR KICKS',
  heroSubtitle: 'PREMIUM CHUNKY SNEAKERS & STREETWEAR SHOES',
  heroCtaText: 'Shop Shoes ↗',
  heroImage: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&q=80&w=1600',
  promoTitle: 'CUSTOM SNEAKERS',
  promoSubtitle: 'STAND OUT WITH BESPOKE CUSTOM SNEAKERS. ELEVATE YOUR FOOTWEAR GAME WITH HAWIX!',
  promoCtaText: 'Explore Kicks ↗',
  promoImage: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&q=80&w=1600',
  announcementText: '⚡ FREE EXPRESS SHIPPING ON ALL SHOE ORDERS OVER ₹2999 | USE CODE HAWIX10 FOR 10% OFF ⚡',
  updatedAt: new Date().toISOString()
};

export const INITIAL_CATEGORIES: CategoryItem[] = [
  {
    id: 'cat-chunky',
    name: 'Chunky Shoes',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
    description: 'Oversized soles, dad sneakers, and heavy 200s chunky skate profiles.'
  },
  {
    id: 'cat-retro',
    name: 'Retro Sneakers',
    image: 'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&q=80&w=800',
    description: 'Vintage indoor soccer, suede classics, and 80s indoor court kicks.'
  },
  {
    id: 'cat-streetwear',
    name: 'Streetwear Shoes',
    image: 'https://images.unsplash.com/photo-1597045566677-8cf032ed6634?auto=format&fit=crop&q=80&w=800',
    description: 'Color-blocked hardcourt basketball staples for daily outfits.'
  },
  {
    id: 'cat-hightop',
    name: 'High-Top Shoes',
    image: 'https://images.unsplash.com/photo-1516478177764-9fe5bd7e9717?auto=format&fit=crop&q=80&w=800',
    description: 'Ankle-supporting heritage high-tops in full-grain premium leather.'
  },
  {
    id: 'cat-custom',
    name: 'Custom Shoes',
    image: 'https://images.unsplash.com/photo-1515955656352-a1fa3ffcd111?auto=format&fit=crop&q=80&w=800',
    description: 'Hand-painted bespoke kicks with sealed acrylic paint and custom motifs.'
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-yeezy-350',
    title: 'Yeezy Boost 350 V2 Sneakers',
    price: 12999,
    originalPrice: 15999,
    stock: 42,
    image: 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&q=80&w=800',
    images: [
      'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&q=80&w=800'
    ],
    colorVariants: [
      {
        colorHex: '#10B981',
        colorName: 'Green Glow',
        image: 'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?auto=format&fit=crop&q=80&w=800',
        images: [
          'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?auto=format&fit=crop&q=80&w=800',
          'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
          'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&q=80&w=800'
        ]
      },
      {
        colorHex: '#111827',
        colorName: 'Onyx Black',
        image: 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&q=80&w=800',
        images: [
          'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&q=80&w=800',
          'https://images.unsplash.com/photo-1516478177764-9fe5bd7e9717?auto=format&fit=crop&q=80&w=800'
        ]
      },
      {
        colorHex: '#E5E7EB',
        colorName: 'Triple White',
        image: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&q=80&w=800',
        images: [
          'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&q=80&w=800',
          'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&q=80&w=800'
        ]
      }
    ],
    category: 'Chunky Shoes',
    brand: 'Yeezy',
    rating: 4.9,
    reviewsCount: 384,
    colors: ['#10B981', '#111827', '#E5E7EB', '#F59E0B'],
    availableSizes: ['India 6', 'India 7', 'India 8', 'India 9', 'India 10', 'India 11'],
    isBestSeller: true,
    isNewArrival: true,
    description: 'Iconic chunky streetwear sneakers featuring Primeknit breathable upper and full-length responsive Boost cushioning.'
  },
  {
    id: 'prod-campus-00s',
    title: 'Adidas Campus 00s Chunky Shoes',
    price: 9999,
    originalPrice: 11999,
    stock: 55,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
    images: [
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&q=80&w=800'
    ],
    colorVariants: [
      {
        colorHex: '#10B981',
        colorName: 'Forest Green',
        image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
        images: [
          'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
          'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?auto=format&fit=crop&q=80&w=800'
        ]
      },
      {
        colorHex: '#EC4899',
        colorName: 'Pink Velvet',
        image: 'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&q=80&w=800',
        images: [
          'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&q=80&w=800',
          'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&q=80&w=800'
        ]
      },
      {
        colorHex: '#3B82F6',
        colorName: 'Royal Blue',
        image: 'https://images.unsplash.com/photo-1597045566677-8cf032ed6634?auto=format&fit=crop&q=80&w=800',
        images: [
          'https://images.unsplash.com/photo-1597045566677-8cf032ed6634?auto=format&fit=crop&q=80&w=800'
        ]
      }
    ],
    category: 'Chunky Shoes',
    brand: 'Adidas',
    rating: 4.8,
    reviewsCount: 290,
    colors: ['#10B981', '#EC4899', '#3B82F6', '#FFFFFF'],
    availableSizes: ['India 6', 'India 7', 'India 8', 'India 9', 'India 10'],
    isBestSeller: true,
    isNewArrival: true,
    description: 'Ultra-chunky 200s skate shoes with oversized padded tongue, wide laces, and premium suede upper.'
  },
  {
    id: 'prod-samba-og',
    title: 'Adidas Samba OG Leather Sneakers',
    price: 8999,
    originalPrice: 10999,
    stock: 60,
    image: 'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&q=80&w=800',
    colorVariants: [
      {
        colorHex: '#FFFFFF',
        colorName: 'Cloud White',
        image: 'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&q=80&w=800',
        images: ['https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&q=80&w=800']
      },
      {
        colorHex: '#000000',
        colorName: 'Core Black',
        image: 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&q=80&w=800',
        images: ['https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&q=80&w=800']
      }
    ],
    category: 'Retro Sneakers',
    brand: 'Adidas',
    rating: 4.8,
    reviewsCount: 410,
    colors: ['#FFFFFF', '#000000', '#1D4ED8', '#6B7280'],
    availableSizes: ['India 7', 'India 8', 'India 9', 'India 10', 'India 11'],
    isBestSeller: true,
    isNewArrival: false,
    description: 'Timeless indoor soccer heritage turned low-top street icon with soft leather upper and suede T-toe.'
  },
  {
    id: 'prod-chunky-platform',
    title: 'Hawix Chunky Platform Dad Shoes',
    price: 6999,
    originalPrice: 8999,
    stock: 80,
    image: 'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&q=80&w=800',
    colorVariants: [
      {
        colorHex: '#10B981',
        colorName: 'Neon Green',
        image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
        images: [
          'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
          'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?auto=format&fit=crop&q=80&w=800'
        ]
      },
      {
        colorHex: '#2563EB',
        colorName: 'Electric Blue',
        image: 'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&q=80&w=800',
        images: [
          'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&q=80&w=800'
        ]
      }
    ],
    category: 'Chunky Shoes',
    brand: 'Hawix',
    rating: 4.9,
    reviewsCount: 185,
    colors: ['#10B981', '#2563EB', '#FFFFFF', '#111827'],
    availableSizes: ['India 6', 'India 7', 'India 8', 'India 9', 'India 10', 'India 11', 'India 12'],
    isBestSeller: true,
    isNewArrival: true,
    description: 'Bold high-profile chunky outsole dad sneakers built for maximum street presence and all-day cushioned comfort.'
  },
  {
    id: 'prod-dunk-low',
    title: 'Nike Dunk Low Retro Kicks',
    price: 10999,
    originalPrice: 12999,
    stock: 48,
    image: 'https://images.unsplash.com/photo-1597045566677-8cf032ed6634?auto=format&fit=crop&q=80&w=800',
    colorVariants: [
      {
        colorHex: '#EF4444',
        colorName: 'University Red',
        image: 'https://images.unsplash.com/photo-1597045566677-8cf032ed6634?auto=format&fit=crop&q=80&w=800',
        images: ['https://images.unsplash.com/photo-1597045566677-8cf032ed6634?auto=format&fit=crop&q=80&w=800']
      },
      {
        colorHex: '#10B981',
        colorName: 'Pine Green',
        image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
        images: ['https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800']
      }
    ],
    category: 'Streetwear Shoes',
    brand: 'Nike',
    rating: 4.9,
    reviewsCount: 520,
    colors: ['#EF4444', '#10B981', '#FFFFFF', '#F59E0B'],
    availableSizes: ['India 7', 'India 8', 'India 9', 'India 10'],
    isBestSeller: false,
    isNewArrival: true,
    description: 'Classic 80s hardwood basketball shoes turned streetwear essential in crisp color-blocked leather.'
  },
  {
    id: 'prod-jordan-1',
    title: 'Air Jordan 1 High OG Sneakers',
    price: 14999,
    originalPrice: 17999,
    stock: 35,
    image: 'https://images.unsplash.com/photo-1516478177764-9fe5bd7e9717?auto=format&fit=crop&q=80&w=800',
    colorVariants: [
      {
        colorHex: '#B91C1C',
        colorName: 'Chicago Red',
        image: 'https://images.unsplash.com/photo-1516478177764-9fe5bd7e9717?auto=format&fit=crop&q=80&w=800',
        images: ['https://images.unsplash.com/photo-1516478177764-9fe5bd7e9717?auto=format&fit=crop&q=80&w=800']
      },
      {
        colorHex: '#111827',
        colorName: 'Bred Toe Black',
        image: 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&q=80&w=800',
        images: ['https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&q=80&w=800']
      }
    ],
    category: 'High-Top Shoes',
    brand: 'Jordan',
    rating: 5.0,
    reviewsCount: 680,
    colors: ['#B91C1C', '#111827', '#FFFFFF'],
    availableSizes: ['India 8', 'India 9', 'India 10', 'India 11'],
    isBestSeller: true,
    isNewArrival: true,
    description: 'The legendary high-top basketball sneaker that started it all, crafted in premium full-grain leather.'
  },
  {
    id: 'prod-custom-sneakers',
    title: 'Hawix Custom Hand-Painted Sneakers',
    price: 15999,
    originalPrice: 18999,
    stock: 15,
    image: 'https://images.unsplash.com/photo-1515955656352-a1fa3ffcd111?auto=format&fit=crop&q=80&w=800',
    category: 'Custom Shoes',
    brand: 'Hawix Custom',
    rating: 5.0,
    reviewsCount: 105,
    colors: ['#84CC16', '#000000', '#FFFFFF', '#F97316'],
    availableSizes: ['India 6', 'India 7', 'India 8', 'India 9', 'India 10', 'India 11'],
    isBestSeller: true,
    isNewArrival: true,
    description: 'Bespoke hand-crafted custom sneakers created by Hawix artists with waterproof acrylic seal and custom motifs.'
  }
];

export const INITIAL_NEWS: NewsArticle[] = [
  {
    id: 'news-1',
    title: 'The Rise of Chunky Sneakers in Streetwear Fashion',
    subtitle: 'Why oversized platform silhouettes and dad shoes dominate modern footwear style.',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
    category: 'Footwear Trend',
    brand: 'HAWIX STYLE',
    readTime: '4 min read'
  },
  {
    id: 'news-2',
    title: 'How to Style Chunky Sneakers for Daily Wear',
    subtitle: 'Pro tips for pairing oversized chunky shoes with wide-leg pants and streetwear fits.',
    image: 'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&q=80&w=800',
    category: 'Styling Guide',
    brand: 'HAWIX STYLE',
    readTime: '5 min read'
  },
  {
    id: 'news-3',
    title: 'Sneaker Care 101: Keep Your Chunky Kicks Clean',
    subtitle: 'Essential suede, mesh, and outsole cleaning methods to prolong sneaker life.',
    image: 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&q=80&w=800',
    category: 'Shoe Maintenance',
    brand: 'HAWIX LAB',
    readTime: '6 min read'
  }
];

export const BRAND_LOGOS = [
  { name: 'Nike', logo: 'https://upload.wikimedia.org/wikipedia/commons/a/a6/Logo_NIKE.svg' },
  { name: 'Adidas', logo: 'https://upload.wikimedia.org/wikipedia/commons/2/20/Adidas_Logo.svg' },
  { name: 'Jordan', logo: 'https://upload.wikimedia.org/wikipedia/en/3/37/Jumpman_logo.svg' },
  { name: 'Converse', logo: 'https://upload.wikimedia.org/wikipedia/commons/3/30/Converse_logo.svg' },
  { name: 'New Balance', logo: 'https://upload.wikimedia.org/wikipedia/commons/e/ea/New_Balance_logo.svg' },
  { name: 'Puma', logo: 'https://upload.wikimedia.org/wikipedia/commons/8/88/Puma_complete_logo.svg' },
  { name: 'Asics', logo: 'https://upload.wikimedia.org/wikipedia/commons/b/b1/Asics_Logo.svg' }
];

export const PARTNERSHIPS = [
  { name: 'Wings', label: 'WINGS' },
  { name: 'National Autistic Society', label: 'National Autistic Society' },
  { name: 'walk MS', label: 'walk MS' },
  { name: 'RUN for AUTISM', label: 'RUN for AUTISM' },
  { name: 'WALK for AUTISM', label: 'WALK for AUTISM' },
  { name: 'autism speaks', label: 'autism speaks' },
  { name: 'autism speaks walk', label: 'autism speaks walk' }
];
