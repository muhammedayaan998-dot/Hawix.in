import React from 'react';
import { ChevronRight } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const FeatureLacesGrid: React.FC = () => {
  const { setSelectedCategory } = useApp();

  const featureCards = [
    {
      title: 'NO-TIE SHOELACES',
      image: 'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?auto=format&fit=crop&q=80&w=800',
      category: 'No-Tie Laces'
    },
    {
      title: 'FAT SHOELACES',
      image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
      category: 'Fat Laces'
    },
    {
      title: 'FUN SHOELACES',
      image: 'https://images.unsplash.com/photo-1515955656352-a1fa3ffcd111?auto=format&fit=crop&q=80&w=800',
      category: 'Custom Laces'
    }
  ];

  const handleSelect = (category: string) => {
    setSelectedCategory(category);
    const elem = document.getElementById('best-sellers-section');
    if (elem) elem.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featureCards.map((card, i) => (
            <div
              key={i}
              onClick={() => handleSelect(card.category)}
              className="group relative h-96 sm:h-[420px] rounded-2xl overflow-hidden cursor-pointer shadow-md hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1"
            >
              <img
                src={card.image}
                alt={card.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              
              <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between text-white">
                <h3 className="font-condensed text-3xl font-extrabold uppercase tracking-tight drop-shadow-md">
                  {card.title}
                </h3>
                <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-xs flex items-center justify-center group-hover:bg-lime-400 group-hover:text-slate-950 transition-colors shadow-xs">
                  <ChevronRight className="w-5 h-5" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
