import React, { useState } from 'react';
import { Star, ShoppingBag, Eye } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Product } from '../types';

interface ProductGridProps {
  title: string;
  id?: string;
  filterType?: 'bestseller' | 'newarrival' | 'all';
}

export const ProductGrid: React.FC<ProductGridProps> = ({ title, id = 'best-sellers-section', filterType = 'all' }) => {
  const { 
    products, 
    categories,
    formatPrice, 
    addToCart, 
    viewProductPage,
    selectedCategory,
    setSelectedCategory,
    selectedBrand,
    setSelectedBrand,
    searchQuery
  } = useApp();

  // Active hover/selected image per product card ID
  const [activeCardImages, setActiveCardImages] = useState<Record<string, string>>({});

  // Filter logic
  const filtered = products.filter(p => {
    if (filterType === 'bestseller' && !p.isBestSeller) return false;
    if (filterType === 'newarrival' && !p.isNewArrival) return false;
    if (selectedCategory !== 'All' && p.category.toLowerCase() !== selectedCategory.toLowerCase()) return false;
    if (selectedBrand !== 'All' && p.brand.toLowerCase() !== selectedBrand.toLowerCase()) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        p.title.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const categoriesList = ['All', ...categories.map(c => c.name)];

  const handleSwatchHover = (productId: string, product: Product, hex: string) => {
    // Check if variant has specific image
    const variant = product.colorVariants?.find(v => v.colorHex.toLowerCase() === hex.toLowerCase());
    if (variant?.image) {
      setActiveCardImages(prev => ({ ...prev, [productId]: variant.image! }));
    }
  };

  return (
    <section id={id} className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header & Filter Controls */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <h2 className="font-condensed text-4xl sm:text-5xl font-extrabold uppercase tracking-tight text-zinc-900">
              {title}
            </h2>
            {(selectedBrand !== 'All' || selectedCategory !== 'All') && (
              <div className="flex items-center gap-2 mt-2">
                <span className="text-xs text-zinc-500 font-medium">Active filters:</span>
                {selectedBrand !== 'All' && (
                  <span className="px-2.5 py-0.5 bg-zinc-900 text-white text-[11px] font-bold rounded-full flex items-center gap-1">
                    Brand: {selectedBrand}
                    <button onClick={() => setSelectedBrand('All')} className="hover:text-red-500">×</button>
                  </span>
                )}
                {selectedCategory !== 'All' && (
                  <span className="px-2.5 py-0.5 bg-zinc-900 text-white text-[11px] font-bold rounded-full flex items-center gap-1">
                    Category: {selectedCategory}
                    <button onClick={() => setSelectedCategory('All')} className="hover:text-red-500">×</button>
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Category Filter Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pb-2 scrollbar-none">
            {categoriesList.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-xs font-bold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  selectedCategory.toLowerCase() === cat.toLowerCase()
                    ? 'bg-red-600 text-white shadow-xs' 
                    : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        {filtered.length === 0 ? (
          <div className="py-16 text-center border-2 border-dashed border-zinc-200 rounded-2xl bg-zinc-50">
            <p className="text-lg font-bold text-zinc-700 mb-1">No shoes found matching your filters</p>
            <p className="text-xs text-zinc-500 mb-4">Try clearing your active filters or search terms.</p>
            <button
              onClick={() => { setSelectedCategory('All'); setSelectedBrand('All'); }}
              className="px-4 py-2 bg-zinc-900 text-white text-xs font-bold rounded-lg hover:bg-red-600 transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {filtered.map(product => {
              const cardImage = activeCardImages[product.id] || product.image;

              return (
                <div 
                  key={product.id}
                  className="group flex flex-col bg-white rounded-2xl overflow-hidden border border-zinc-200 hover:border-zinc-400 hover:shadow-xl transition-all duration-300"
                >
                  {/* Product Image Container */}
                  <div 
                    onClick={() => viewProductPage(product)}
                    className="relative aspect-square bg-zinc-50 overflow-hidden cursor-pointer"
                  >
                    <img
                      src={cardImage}
                      alt={product.title}
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                    />
                    
                    {/* Badges */}
                    <div className="absolute top-2 left-2 flex flex-col gap-1">
                      {product.isBestSeller && (
                        <span className="bg-zinc-950 text-white text-[10px] uppercase font-black px-2 py-0.5 rounded-xs tracking-wider shadow-xs">
                          Best Seller
                        </span>
                      )}
                      {product.stock <= 20 && (
                        <span className="bg-red-600 text-white text-[10px] uppercase font-bold px-2 py-0.5 rounded-xs">
                          Low Stock ({product.stock})
                        </span>
                      )}
                    </div>

                    {/* Quick Add Overlay */}
                    <div className="absolute bottom-2 inset-x-2 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                      <button
                        onClick={(e) => { e.stopPropagation(); addToCart(product); }}
                        className="flex-1 py-2 px-3 bg-zinc-950 hover:bg-red-600 text-white text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-md"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                        Add to Cart
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); viewProductPage(product); }}
                        className="p-2 bg-white hover:bg-zinc-100 text-zinc-800 rounded-lg shadow-md transition-colors"
                        title="View Product Page"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Card Info */}
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div onClick={() => viewProductPage(product)} className="cursor-pointer">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h3 className="text-xs sm:text-sm font-bold text-zinc-900 group-hover:text-red-600 transition-colors line-clamp-2">
                          {product.title}
                        </h3>
                        <div className="flex items-center gap-0.5 text-amber-500 text-[11px] font-bold shrink-0">
                          <span>{product.rating}</span>
                          <Star className="w-3 h-3 fill-current" />
                        </div>
                      </div>

                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <span className="text-sm sm:text-base font-black text-zinc-900">
                          {formatPrice(product.price)}
                        </span>
                        <span className="text-xs text-zinc-400 line-through font-semibold">
                          {formatPrice(product.originalPrice || Math.round(product.price * 1.25))}
                        </span>
                        <span className="text-[10px] font-extrabold text-red-600 bg-red-50 px-1.5 py-0.5 rounded">
                          {Math.round((((product.originalPrice || Math.round(product.price * 1.25)) - product.price) / (product.originalPrice || Math.round(product.price * 1.25))) * 100)}% OFF
                        </span>
                      </div>
                    </div>

                    {/* Color Swatch Thumbnails with dynamic image swap on hover/click */}
                    <div className="mt-3 pt-2 border-t border-zinc-100 flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        {product.colors.slice(0, 4).map((hex, idx) => (
                          <button
                            key={idx} 
                            onClick={(e) => {
                              e.stopPropagation();
                              handleSwatchHover(product.id, product, hex);
                            }}
                            onMouseEnter={() => handleSwatchHover(product.id, product, hex)}
                            className="w-4 h-4 rounded-full border border-zinc-300 shadow-2xs hover:scale-125 transition-transform"
                            style={{ backgroundColor: hex }}
                            title="Click or hover to view color variant"
                          />
                        ))}
                      </div>
                      <span className="text-[10px] font-bold text-zinc-400 bg-zinc-100 px-1.5 py-0.5 rounded">
                        {product.colors.length} colors
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};
