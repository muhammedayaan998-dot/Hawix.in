import React from 'react';
import { useApp } from '../context/AppContext';
import { ArrowUpRight } from 'lucide-react';

export const PromoBanner: React.FC = () => {
  const { siteConfig, setIsCustomLaceModalOpen } = useApp();

  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-zinc-950 min-h-[380px] sm:min-h-[460px] flex items-center shadow-2xl">
          
          {/* Background Image */}
          <div className="absolute inset-0 z-0">
            <img
              src={siteConfig.promoImage}
              alt="Custom Sneaker Shoes Promo"
              className="w-full h-full object-cover object-center opacity-75"
            />
            {/* Scrim */}
            <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/50 to-black/80 sm:to-transparent" />
          </div>

          {/* Grid Content */}
          <div className="relative z-10 w-full p-8 sm:p-14 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
            
            {/* Left Subtitle callout */}
            <div className="max-w-sm">
              <span className="inline-block text-[11px] font-extrabold uppercase tracking-widest text-red-500 bg-red-600/10 border border-red-500/30 px-3 py-1 rounded-full mb-3">
                HAWIX CUSTOM SHOE LAB
              </span>
              <p className="text-sm sm:text-base font-bold uppercase tracking-wide leading-relaxed text-zinc-200">
                {siteConfig.promoSubtitle}
              </p>
            </div>

            {/* Right Headline & Action */}
            <div className="flex flex-col items-start md:items-end text-left md:text-right">
              <h2 className="font-condensed text-5xl sm:text-7xl lg:text-8xl font-black uppercase tracking-tight text-white leading-none drop-shadow-lg">
                {siteConfig.promoTitle.split(' ').map((w, i) => (
                  <span key={i} className={w.toUpperCase() === 'CUSTOM' ? 'text-red-600 block' : 'block'}>
                    {w}
                  </span>
                ))}
              </h2>

              <button
                onClick={() => setIsCustomLaceModalOpen(true)}
                className="mt-6 px-8 py-3.5 bg-red-600 hover:bg-red-700 text-white font-condensed text-lg font-bold uppercase tracking-wider rounded-xl transition-all flex items-center gap-2 shadow-lg shadow-red-600/30 cursor-pointer"
              >
                <span>{siteConfig.promoCtaText}</span>
                <ArrowUpRight className="w-5 h-5 stroke-[3]" />
              </button>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};
