import React from 'react';
import { useApp } from '../context/AppContext';
import { ArrowUpRight } from 'lucide-react';

export const Hero: React.FC = () => {
  const { siteConfig } = useApp();

  const handleShopNowClick = () => {
    const elem = document.getElementById('best-sellers-section');
    if (elem) elem.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative w-full bg-zinc-950 overflow-hidden min-h-[520px] sm:min-h-[640px] flex items-center">
      {/* Background Hero Image with Overlays */}
      <div className="absolute inset-0 z-0">
        <img
          src={siteConfig.heroImage}
          alt="Level Up Your Kicks Hero"
          className="w-full h-full object-cover object-center opacity-85 scale-105 transform transition-transform duration-1000"
        />
        {/* Dark Scrim & Gradient for Text Contrast */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/95 via-black/70 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-black/50" />
      </div>

      {/* Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 text-white w-full">
        <div className="max-w-2xl">
          
          {/* Main Bold Condensed Headline */}
          <h1 className="font-condensed text-5xl sm:text-7xl lg:text-8xl font-extrabold tracking-tight uppercase leading-[0.9] text-white drop-shadow-md">
            {siteConfig.heroTitle.split(' ').map((word, i) => (
              <span 
                key={i} 
                className={word.toUpperCase() === 'KICKS' || word.toUpperCase() === 'SHOES' || word.toUpperCase() === 'HAWIX' ? 'text-red-600 block' : 'block'}
              >
                {word}{' '}
              </span>
            ))}
          </h1>

          {/* Subtitle */}
          <p className="mt-4 sm:mt-6 text-sm sm:text-base font-semibold tracking-wider text-zinc-300 uppercase">
            {siteConfig.heroSubtitle}
          </p>

          {/* CTA Button */}
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <button
              onClick={handleShopNowClick}
              className="px-8 py-4 bg-red-600 hover:bg-red-700 text-white font-condensed text-xl font-bold uppercase tracking-wider rounded-xl hover:scale-105 transition-all flex items-center gap-2 shadow-lg shadow-red-600/30 cursor-pointer"
            >
              <span>{siteConfig.heroCtaText}</span>
              <ArrowUpRight className="w-6 h-6 stroke-[3]" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
