import React from 'react';
import { ChevronRight } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const CategoryGrid: React.FC = () => {
  const { categories, setSelectedCategory, setSelectedBrand } = useApp();

  const handleCardClick = (categoryName: string) => {
    setSelectedCategory(categoryName);
    setSelectedBrand('All');
    const elem = document.getElementById('best-sellers-section');
    if (elem) elem.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="font-condensed text-4xl sm:text-5xl font-extrabold uppercase tracking-tight text-zinc-900">
              EXPLORE SHOE CATEGORIES
            </h2>
            <p className="text-xs text-zinc-500 font-medium">Select a category to view customized shoe collections</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((cat) => (
            <div
              key={cat.id}
              onClick={() => handleCardClick(cat.name)}
              className="group relative h-72 sm:h-80 rounded-3xl overflow-hidden cursor-pointer shadow-md hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 border border-zinc-200"
            >
              {/* Image */}
              <img
                src={cat.image}
                alt={cat.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
              
              {/* Content */}
              <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between text-white">
                <div>
                  <span className="text-[10px] uppercase font-bold text-red-500 tracking-wider block mb-0.5">
                    Category Collection
                  </span>
                  <h3 className="font-condensed text-2xl font-black uppercase tracking-tight drop-shadow-md">
                    {cat.name}
                  </h3>
                  {cat.description && (
                    <p className="text-xs text-zinc-300 line-clamp-1 mt-1 font-medium">{cat.description}</p>
                  )}
                </div>
                <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-xs flex items-center justify-center group-hover:bg-red-600 group-hover:text-white transition-colors shadow-xs shrink-0 ml-2">
                  <ChevronRight className="w-5 h-5" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
