import React from 'react';
import { Facebook, Instagram, Shield } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Footer: React.FC = () => {
  const { 
    setSelectedBrand, 
    setIsCustomLaceModalOpen, 
    setIsLoginModalOpen,
    setIsAdminPortalOpen,
    setIsTrackOrderOpen,
    isAdmin 
  } = useApp();

  const handleBrandClick = (b: string) => {
    setSelectedBrand(b);
    const elem = document.getElementById('best-sellers-section');
    if (elem) elem.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="relative bg-zinc-950 text-white pt-16 pb-8 overflow-hidden border-t border-zinc-800">
      
      {/* Red Accent Glow Banner */}
      <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-red-600 via-red-500 to-red-700" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-32 bg-red-600/10 blur-3xl rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top Footer Logo & Socials */}
        <div className="flex flex-col sm:flex-row items-center justify-between pb-12 border-b border-zinc-800 gap-6">
          <a href="#" className="font-condensed text-5xl sm:text-6xl font-black tracking-tighter text-white">
            HAWIX<span className="text-red-600">.IN</span>
          </a>
          
          <div className="flex items-center gap-4">
            <a 
              href="https://facebook.com" 
              target="_blank" 
              rel="noreferrer"
              className="w-10 h-10 rounded-full bg-zinc-900 hover:bg-red-600 hover:text-white flex items-center justify-center transition-colors text-zinc-300"
              aria-label="Facebook"
            >
              <Facebook className="w-5 h-5" />
            </a>
            <a 
              href="https://instagram.com" 
              target="_blank" 
              rel="noreferrer"
              className="w-10 h-10 rounded-full bg-zinc-900 hover:bg-red-600 hover:text-white flex items-center justify-center transition-colors text-zinc-300"
              aria-label="Instagram"
            >
              <Instagram className="w-5 h-5" />
            </a>
          </div>
        </div>

        {/* 4 Footer Columns */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 py-12 text-xs">
          
          {/* Column 1: Shoes For Brands */}
          <div>
            <h4 className="font-bold uppercase tracking-wider text-white text-sm mb-4">
              Shoes By Brand
            </h4>
            <ul className="space-y-2 text-zinc-400 font-medium">
              {['Adidas', 'Asics', 'Converse', 'Jordan', 'New Balance', 'Nike', 'Puma', 'Yeezy', 'Hawix'].map((brand) => (
                <li key={brand}>
                  <button 
                    onClick={() => handleBrandClick(brand)} 
                    className="hover:text-red-600 transition-colors text-left"
                  >
                    {brand} Shoes
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 2: Customer Service */}
          <div>
            <h4 className="font-bold uppercase tracking-wider text-white text-sm mb-4">
              Customer Support
            </h4>
            <ul className="space-y-2.5 text-zinc-400 font-medium">
              <li><button onClick={() => setIsCustomLaceModalOpen(true)} className="hover:text-red-600">Contact Us</button></li>
              <li><a href="#news-section" className="hover:text-red-600">Size & Fitting Guide</a></li>
              <li><a href="#" className="hover:text-red-600">Returns & Exchanges</a></li>
              <li><a href="#" className="hover:text-red-600">Free Shipping Info</a></li>
              <li><button onClick={() => setIsTrackOrderOpen(true)} className="hover:text-red-600 font-bold text-white">Track Order</button></li>
            </ul>
          </div>

          {/* Column 3: Information */}
          <div>
            <h4 className="font-bold uppercase tracking-wider text-white text-sm mb-4">
              Explore Hawix
            </h4>
            <ul className="space-y-2.5 text-zinc-400 font-medium">
              <li><a href="#" className="hover:text-red-600">About Hawix Store</a></li>
              <li><a href="#news-section" className="hover:text-red-600">Chunky Shoe Trends</a></li>
              <li><button onClick={() => setIsCustomLaceModalOpen(true)} className="hover:text-red-600">Custom Shoes Order</button></li>
              <li><a href="#" className="hover:text-red-600">Authenticity Guarantee</a></li>
            </ul>
          </div>

          {/* Column 4: Hawix Shoes Info */}
          <div>
            <h4 className="font-bold uppercase tracking-wider text-white text-sm mb-4">
              Hawix Footwear
            </h4>
            <p className="text-zinc-400 leading-relaxed font-normal mb-4">
              The official Hawix.in online store for chunky sneakers, retro court shoes, and custom hand-painted kicks. Express shipping across India.
            </p>
            <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl">
              <span className="text-[11px] font-bold text-red-500 block mb-1">⚡ NEED CUSTOM SNEAKERS?</span>
              <p className="text-[11px] text-zinc-400">We paint bespoke hand-crafted sneakers for events, creators, and sneakerheads.</p>
            </div>
          </div>
        </div>

        {/* Bottom Bar & Secret Admin Access */}
        <div className="pt-8 border-t border-zinc-900 flex flex-col sm:flex-row items-center justify-between text-zinc-500 text-[11px] font-medium gap-4">
          <p>© 2026, Hawix.in. All rights reserved.</p>
          
          <div className="flex items-center gap-4">
            <button
              onClick={() => {
                if (isAdmin) {
                  setIsAdminPortalOpen(true);
                } else {
                  setIsLoginModalOpen(true);
                }
              }}
              className="text-zinc-400 hover:text-red-500 flex items-center gap-1 transition-colors font-bold"
            >
              <Shield className="w-3.5 h-3.5 text-red-600" />
              <span>{isAdmin ? 'Admin Dashboard' : 'Admin Portal Login'}</span>
            </button>
            <span>·</span>
            <a href="#" className="hover:text-zinc-300">Privacy Policy</a>
            <span>·</span>
            <a href="#" className="hover:text-zinc-300">Terms of Service</a>
          </div>
        </div>

      </div>
    </footer>
  );
};
