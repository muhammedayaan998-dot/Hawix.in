import React, { useState } from 'react';
import { Search, ShoppingBag, User as UserIcon, Shield, Menu, X, ChevronDown, Truck, Package } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Header: React.FC = () => {
  const { 
    siteConfig, 
    cartCount, 
    setIsLoginModalOpen, 
    setIsSearchModalOpen, 
    setIsCartDrawerOpen,
    setIsAdminPortalOpen,
    setIsCustomLaceModalOpen,
    setIsTrackOrderOpen,
    isAdmin,
    setSelectedCategory,
    setSelectedBrand
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [brandDropdownOpen, setBrandDropdownOpen] = useState<boolean>(false);

  const brandsList = ['Nike', 'Adidas', 'Jordan', 'Converse', 'New Balance', 'Puma', 'Asics', 'Yeezy', 'Hawix'];

  const handleBrandSelect = (brandName: string) => {
    setSelectedBrand(brandName);
    setBrandDropdownOpen(false);
    setMobileMenuOpen(false);
    const elem = document.getElementById('best-sellers-section');
    if (elem) elem.scrollIntoView({ behavior: 'smooth' });
  };

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    setMobileMenuOpen(false);
    const elem = document.getElementById('best-sellers-section');
    if (elem) elem.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-zinc-200 shadow-xs">
      {/* Top Announcement Bar */}
      <div className="bg-zinc-950 text-white text-xs py-2 px-4 text-center font-medium tracking-wide flex items-center justify-center gap-2">
        <span className="truncate">{siteConfig.announcementText}</span>
        {isAdmin && (
          <span className="bg-red-600 text-white text-[10px] uppercase font-bold px-2 py-0.5 rounded-full shrink-0 animate-pulse">
            Admin Mode Active
          </span>
        )}
      </div>

      {/* Main Navigation Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
        
        {/* Mobile Hamburger Toggle */}
        <div className="flex items-center lg:hidden">
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-md text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100 transition-colors"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Brand Wordmark: HAWIX in white, .IN in black */}
        <div className="flex items-center gap-3">
          <a href="#" className="group flex items-center gap-1.5">
            <div className="bg-zinc-950 px-3 py-1.5 rounded-xl flex items-center shadow-xs">
              <span className="font-condensed text-2xl sm:text-3xl font-black tracking-tighter text-white">
                HAWIX
              </span>
              <span className="font-condensed text-2xl sm:text-3xl font-black tracking-tighter text-black bg-white px-1 ml-1 rounded">
                .IN
              </span>
            </div>
            <span className="hidden sm:inline-block text-[9px] uppercase tracking-widest text-zinc-500 font-bold border-l border-zinc-300 pl-2">
              SNEAKERS & CHUNKY SHOES
            </span>
          </a>
        </div>

        {/* Navigation Links (Desktop) */}
        <nav className="hidden lg:flex items-center gap-7 text-xs uppercase font-bold tracking-wider text-zinc-800">
          <a 
            href="#" 
            onClick={() => { setSelectedCategory('All'); setSelectedBrand('All'); }}
            className="hover:text-red-600 transition-colors py-2 whitespace-nowrap shrink-0 border-b-2 border-transparent hover:border-red-600"
          >
            Home
          </a>
          
          <button 
            onClick={() => handleCategorySelect('Chunky Shoes')}
            className="hover:text-red-600 transition-colors py-2 whitespace-nowrap shrink-0 border-b-2 border-transparent hover:border-red-600 text-zinc-950 font-extrabold"
          >
            Chunky Shoes
          </button>

          {/* Shoes by Brand Dropdown */}
          <div className="relative">
            <button 
              onClick={() => setBrandDropdownOpen(!brandDropdownOpen)}
              className="flex items-center gap-1 hover:text-red-600 transition-colors py-2 whitespace-nowrap shrink-0 border-b-2 border-transparent hover:border-red-600"
            >
              <span>Shoes by Brand</span>
              <ChevronDown className="w-3.5 h-3.5" />
            </button>

            {brandDropdownOpen && (
              <div className="absolute top-full left-0 w-52 bg-white border border-zinc-200 shadow-xl rounded-b-lg py-2 z-50 animate-in fade-in slide-in-from-top-1">
                {brandsList.map(b => (
                  <button
                    key={b}
                    onClick={() => handleBrandSelect(b)}
                    className="w-full text-left px-4 py-2 text-xs font-semibold text-zinc-700 hover:bg-zinc-50 hover:text-red-600 transition-colors"
                  >
                    {b} Shoes
                  </button>
                ))}
              </div>
            )}
          </div>

          <button 
            onClick={() => handleCategorySelect('Retro Sneakers')}
            className="hover:text-red-600 transition-colors py-2 whitespace-nowrap shrink-0 border-b-2 border-transparent hover:border-red-600"
          >
            Retro Sneakers
          </button>

          <button 
            onClick={() => setIsCustomLaceModalOpen(true)}
            className="hover:text-red-600 transition-colors py-2 whitespace-nowrap shrink-0 border-b-2 border-transparent hover:border-red-600 text-red-600 font-extrabold"
          >
            Custom Shoes
          </button>

          <button 
            onClick={() => setIsTrackOrderOpen(true)}
            className="hover:text-red-600 transition-colors py-2 whitespace-nowrap shrink-0 border-b-2 border-transparent hover:border-red-600 flex items-center gap-1.5 text-zinc-950 font-extrabold"
          >
            <Truck className="w-4 h-4 text-red-600" />
            <span>Track Order</span>
          </button>
        </nav>

        {/* Right Action Controls */}
        <div className="flex items-center gap-3 sm:gap-4 shrink-0">
          
          {/* Search Icon */}
          <button
            onClick={() => setIsSearchModalOpen(true)}
            className="p-2 text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100 rounded-full transition-colors relative"
            title="Search Shoes"
            aria-label="Search Shoes"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Customer Track Order Quick Button */}
          <button
            onClick={() => setIsTrackOrderOpen(true)}
            className="p-2 text-zinc-700 hover:text-red-600 hover:bg-zinc-100 rounded-full transition-colors relative hidden sm:flex items-center gap-1 font-bold text-xs"
            title="Track Your Order"
          >
            <Package className="w-5 h-5" />
          </button>

          {/* User Account / Secret Admin Portal Icon */}
          <button
            onClick={() => {
              if (isAdmin) {
                setIsAdminPortalOpen(true);
              } else {
                setIsLoginModalOpen(true);
              }
            }}
            className={`p-2 rounded-full transition-colors flex items-center gap-1.5 ${
              isAdmin 
                ? 'bg-red-600 text-white font-bold px-3 py-1.5 hover:bg-red-700 shadow-xs' 
                : 'text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100'
            }`}
            title={isAdmin ? 'Admin Dashboard' : 'Account Login'}
          >
            {isAdmin ? (
              <>
                <Shield className="w-4 h-4 fill-current" />
                <span className="text-xs font-bold hidden sm:inline">Admin Portal</span>
              </>
            ) : (
              <UserIcon className="w-5 h-5" />
            )}
          </button>

          {/* Cart Drawer Icon */}
          <button
            onClick={() => setIsCartDrawerOpen(true)}
            className="p-2 text-zinc-950 hover:bg-zinc-100 rounded-full transition-colors relative"
            aria-label="Shopping Cart"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-600 text-white font-extrabold text-[11px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-white shadow-xs">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-zinc-200 bg-white px-4 py-4 space-y-3 animate-in slide-in-from-top duration-200">
          <div className="flex items-center gap-2 mb-2">
            <button
              onClick={() => setIsSearchModalOpen(true)}
              className="w-full flex items-center justify-between px-4 py-2.5 bg-zinc-100 rounded-lg text-zinc-500 text-xs font-medium"
            >
              <span>Search chunky shoes, sneakers, brands...</span>
              <Search className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-1 text-sm font-bold text-zinc-800">
            <button 
              onClick={() => { setSelectedCategory('All'); setSelectedBrand('All'); setMobileMenuOpen(false); }}
              className="block w-full text-left py-2 px-3 hover:bg-zinc-50 rounded-md"
            >
              Home
            </button>
            <button 
              onClick={() => handleCategorySelect('Chunky Shoes')}
              className="block w-full text-left py-2 px-3 hover:bg-zinc-50 rounded-md"
            >
              Chunky Shoes
            </button>
            <div className="py-1 px-3">
              <span className="text-xs uppercase text-zinc-400 font-bold block mb-1">Browse Brands</span>
              <div className="grid grid-cols-2 gap-2">
                {brandsList.map(b => (
                  <button
                    key={b}
                    onClick={() => handleBrandSelect(b)}
                    className="text-left text-xs py-1.5 px-2 bg-zinc-50 hover:bg-zinc-100 rounded text-zinc-700 font-semibold"
                  >
                    {b} Shoes
                  </button>
                ))}
              </div>
            </div>
            <button 
              onClick={() => handleCategorySelect('Retro Sneakers')}
              className="block w-full text-left py-2 px-3 hover:bg-zinc-50 rounded-md"
            >
              Retro Sneakers
            </button>
            <button 
              onClick={() => { setIsCustomLaceModalOpen(true); setMobileMenuOpen(false); }}
              className="block w-full text-left py-2 px-3 text-red-600 bg-red-50 rounded-md font-extrabold"
            >
              Custom Shoes ↗
            </button>
            <button 
              onClick={() => { setIsTrackOrderOpen(true); setMobileMenuOpen(false); }}
              className="block w-full text-left py-2 px-3 text-zinc-900 bg-zinc-100 hover:bg-zinc-200 rounded-md font-extrabold flex items-center gap-2"
            >
              <Truck className="w-4 h-4 text-red-600" />
              Track Order Status
            </button>
            {isAdmin && (
              <button 
                onClick={() => { setIsAdminPortalOpen(true); setMobileMenuOpen(false); }}
                className="block w-full text-left py-2 px-3 text-white bg-red-600 rounded-md font-extrabold flex items-center gap-2"
              >
                <Shield className="w-4 h-4 text-white" />
                Admin Dashboard
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
