import React from 'react';
import { PARTNERSHIPS } from '../data/initialData';

export const PartnershipsBanner: React.FC = () => {
  return (
    <section className="py-12 bg-white border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        
        <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-8">
          Partnerships & Activations
        </h4>

        <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-10 opacity-75">
          {PARTNERSHIPS.map((p, idx) => (
            <div 
              key={idx}
              className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600 text-xs sm:text-sm font-bold tracking-tight hover:opacity-100 transition-opacity bg-slate-50/50"
            >
              {p.label}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
