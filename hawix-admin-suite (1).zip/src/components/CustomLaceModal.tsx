import React, { useState } from 'react';
import { X, Sparkles, Send, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const CustomLaceModal: React.FC = () => {
  const { isCustomLaceModalOpen, setIsCustomLaceModalOpen, submitEnquiry } = useApp();

  const [name, setName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [laceText, setLaceText] = useState<string>('');
  const [colorPref, setColorPref] = useState<string>('Red & Black');
  const [quantity, setQuantity] = useState<string>('1 pair');
  const [details, setDetails] = useState<string>('');
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  if (!isCustomLaceModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) return;
    setIsSubmitting(true);
    await submitEnquiry({
      name,
      email,
      subject: `Custom Sneaker Request (${quantity})`,
      message: `Custom Text: "${laceText}" | Color: ${colorPref} | Quantity: ${quantity} | Additional details: ${details}`
    });
    setIsSubmitting(false);
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div 
        className="bg-white max-w-lg w-full rounded-2xl shadow-2xl overflow-hidden border border-zinc-200 relative"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 bg-zinc-950 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-red-600" />
            <h3 className="font-condensed text-2xl font-extrabold uppercase tracking-wider">
              HAWIX CUSTOM SHOE LAB
            </h3>
          </div>
          <button 
            onClick={() => {
              setIsCustomLaceModalOpen(false);
              setSubmitted(false);
            }} 
            className="p-1 text-zinc-400 hover:text-white rounded-md"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {submitted ? (
            <div className="py-8 text-center space-y-4">
              <CheckCircle2 className="w-16 h-16 text-emerald-600 mx-auto" />
              <h4 className="text-2xl font-bold text-zinc-900">Custom Sneaker Request Received!</h4>
              <p className="text-xs text-zinc-500 max-w-xs mx-auto">
                Our custom footwear team will review your sneaker design specifications and contact you within 24 hours.
              </p>
              <button
                onClick={() => {
                  setSubmitted(false);
                  setIsCustomLaceModalOpen(false);
                }}
                className="w-full py-3 bg-red-600 text-white font-bold text-xs uppercase rounded-xl hover:bg-red-700 transition-colors"
              >
                Done
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <p className="text-xs text-zinc-600">
                Design custom painted or custom colorway sneakers for your personal collection, event, or team.
              </p>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-zinc-700 block mb-1">Your Name *</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Muhammed Ayaan"
                    className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-zinc-700 block mb-1">Email *</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="ayaan@hawix.in"
                    className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-zinc-700 block mb-1">Custom Text or Hand-Paint Theme</label>
                <input
                  type="text"
                  value={laceText}
                  onChange={(e) => setLaceText(e.target.value)}
                  placeholder="e.g. Anime Paint Theme or Custom Monogram"
                  className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600 font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-zinc-700 block mb-1">Color Palette</label>
                  <input
                    type="text"
                    value={colorPref}
                    onChange={(e) => setColorPref(e.target.value)}
                    placeholder="Red, White & Black"
                    className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-zinc-700 block mb-1">Shoe Size / Quantity</label>
                  <select
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600 bg-white"
                  >
                    <option value="1 pair">1 Pair (UK 8)</option>
                    <option value="2 pairs">2 Pairs</option>
                    <option value="5+ pairs">5+ Pairs</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-zinc-700 block mb-1">Additional Custom Requirements</label>
                <textarea
                  rows={2}
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  placeholder="Specific base shoe model (Nike Dunk, Air Force 1, Yeezy) or custom artwork details..."
                  className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600 resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-colors shadow-md flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                {isSubmitting ? 'Sending Request...' : 'Submit Custom Request'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
