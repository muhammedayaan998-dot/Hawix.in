import React, { useState } from 'react';
import { 
  Star, 
  ShoppingBag, 
  Truck, 
  ShieldCheck, 
  RotateCcw, 
  ArrowLeft,
  Share2,
  Heart,
  Check,
  Lock,
  ChevronLeft,
  ChevronRight,
  MoveHorizontal
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ProductPage: React.FC = () => {
  const { 
    selectedProductPage, 
    setSelectedProductPage, 
    products, 
    formatPrice, 
    addToCart, 
    setIsCartDrawerOpen,
    viewProductPage 
  } = useApp();

  const [selectedColor, setSelectedColor] = useState<string>('');
  const [selectedImageIndex, setSelectedImageIndex] = useState<number>(0);
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [activeTab, setActiveTab] = useState<'overview' | 'reviews'>('overview');

  // Touch swipe states
  const [touchStartX, setTouchStartX] = useState<number | null>(null);
  const [touchEndX, setTouchEndX] = useState<number | null>(null);

  if (!selectedProductPage) return null;

  const product = selectedProductPage;
  const activeColor = selectedColor || (product.colors && product.colors.length > 0 ? product.colors[0] : '#000000');

  // Reset selected image index when product or color selection changes
  React.useEffect(() => {
    setSelectedImageIndex(0);
  }, [product.id, selectedColor]);

  // Find mapped color variant image if present
  const mappedVariant = product.colorVariants?.find(
    v => v.colorHex.toLowerCase() === activeColor.toLowerCase() || v.colorName.toLowerCase() === activeColor.toLowerCase()
  );

  // Sizes available for this shoe (India Sizing)
  const shoeSizes = product.availableSizes && product.availableSizes.length > 0 
    ? product.availableSizes 
    : ['India 6', 'India 7', 'India 8', 'India 9', 'India 10', 'India 11', 'India 12'];

  const currentSize = selectedSize || shoeSizes[0];

  const discountPercent = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const relatedProducts = products.filter(p => p.id !== product.id).slice(0, 4);

  // Gallery images array for selected color variant or product gallery
  const activeColorImages = mappedVariant?.images && mappedVariant.images.length > 0
    ? mappedVariant.images
    : (mappedVariant?.image ? [mappedVariant.image] : []);

  const baseProductImages = Array.from(new Set([
    product.image,
    ...(product.images || [])
  ].filter(Boolean)));

  const allGalleryImages = Array.from(new Set(
    activeColorImages.length > 0
      ? [...activeColorImages, ...baseProductImages]
      : (baseProductImages.length > 0 ? baseProductImages : ['https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800'])
  ));

  const currentImage = allGalleryImages[selectedImageIndex % allGalleryImages.length] || product.image;

  // Swipe handlers
  const handleNextImage = () => {
    setSelectedImageIndex(prev => (prev + 1) % allGalleryImages.length);
  };

  const handlePrevImage = () => {
    setSelectedImageIndex(prev => (prev - 1 + allGalleryImages.length) % allGalleryImages.length);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStartX(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEndX(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (!touchStartX || !touchEndX) return;
    const distance = touchStartX - touchEndX;
    const minSwipeDistance = 40;

    if (distance > minSwipeDistance) {
      // Swiped Left -> Next image
      handleNextImage();
    } else if (distance < -minSwipeDistance) {
      // Swiped Right -> Prev image
      handlePrevImage();
    }

    setTouchStartX(null);
    setTouchEndX(null);
  };

  const handleBuyNow = () => {
    addToCart(product, activeColor, quantity);
    setIsCartDrawerOpen(true);
  };

  const handleColorClick = (hex: string) => {
    setSelectedColor(hex);
    // Find variant image for this color hex and set selected image index to 0
    const variantIdx = product.colorVariants?.findIndex(
      v => v.colorHex.toLowerCase() === hex.toLowerCase()
    );
    if (variantIdx !== undefined && variantIdx !== -1) {
      setSelectedImageIndex(0);
    }
  };

  return (
    <div className="bg-zinc-50 min-h-screen pb-16 text-zinc-900 animate-in fade-in duration-200">
      
      {/* Top Breadcrumb Bar */}
      <div className="bg-white border-b border-zinc-200 px-4 sm:px-8 py-3 text-xs font-semibold text-zinc-500">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2 flex-wrap">
            <button 
              onClick={() => setSelectedProductPage(null)} 
              className="text-zinc-700 hover:text-red-600 font-bold flex items-center gap-1 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Store</span>
            </button>
            <span className="text-zinc-300">/</span>
            <span>Shoes & Kicks</span>
            <span className="text-zinc-300">/</span>
            <span className="text-zinc-700 font-bold">{product.brand}</span>
            <span className="text-zinc-300">/</span>
            <span className="text-zinc-900 font-extrabold truncate max-w-[200px] sm:max-w-md">{product.title}</span>
          </div>

          <div className="hidden sm:flex items-center gap-3 text-zinc-600">
            <button className="hover:text-zinc-900 flex items-center gap-1">
              <Share2 className="w-3.5 h-3.5" /> Share
            </button>
            <button className="hover:text-red-600 flex items-center gap-1">
              <Heart className="w-3.5 h-3.5" /> Wishlist
            </button>
          </div>
        </div>
      </div>

      {/* Main Product Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        
        {/* Amazon-style Product Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 bg-white p-6 sm:p-8 rounded-3xl border border-zinc-200 shadow-sm">
          
          {/* Column 1: Image & Gallery (5 Cols) with SWIPE feature */}
          <div className="lg:col-span-5 flex flex-col items-center">
            
            {/* Main Big Photo Frame with Swipe Gestures */}
            <div 
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
              className="relative w-full aspect-square bg-zinc-100 rounded-2xl overflow-hidden border border-zinc-200 group flex items-center justify-center p-4 cursor-grab active:cursor-grabbing select-none"
            >
              <img
                src={currentImage}
                alt={product.title}
                className="w-full h-full object-cover object-center transition-all duration-300"
              />
              
              {/* Badges */}
              {product.isBestSeller && (
                <span className="absolute top-4 left-4 bg-zinc-950 text-white text-xs font-black uppercase px-3 py-1 rounded-sm shadow-sm tracking-wider flex items-center gap-1 z-10">
                  <span className="w-2 h-2 rounded-full bg-red-500" /> Best Seller in {product.category}
                </span>
              )}
              {discountPercent > 0 && (
                <span className="absolute top-4 right-4 bg-red-600 text-white text-xs font-black px-2.5 py-1 rounded-md shadow-sm z-10">
                  {discountPercent}% OFF
                </span>
              )}

              {/* Swipe Controls: Previous & Next Arrows */}
              {allGalleryImages.length > 1 && (
                <>
                  <button
                    onClick={(e) => { e.stopPropagation(); handlePrevImage(); }}
                    className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/90 hover:bg-zinc-950 hover:text-white text-zinc-900 shadow-md flex items-center justify-center transition-all opacity-80 hover:opacity-100 z-20"
                    aria-label="Previous Image"
                  >
                    <ChevronLeft className="w-6 h-6" />
                  </button>

                  <button
                    onClick={(e) => { e.stopPropagation(); handleNextImage(); }}
                    className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/90 hover:bg-zinc-950 hover:text-white text-zinc-900 shadow-md flex items-center justify-center transition-all opacity-80 hover:opacity-100 z-20"
                    aria-label="Next Image"
                  >
                    <ChevronRight className="w-6 h-6" />
                  </button>

                  {/* Swipe Counter Pill */}
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-zinc-950/80 backdrop-blur-xs text-white text-[11px] font-bold px-3 py-1 rounded-full flex items-center gap-1.5 shadow-md z-10">
                    <MoveHorizontal className="w-3.5 h-3.5 text-red-500 animate-pulse" />
                    <span>Swipe to view {selectedImageIndex + 1} / {allGalleryImages.length}</span>
                  </div>
                </>
              )}
            </div>

            {/* Gallery Thumbnails */}
            <div className="flex items-center gap-3 mt-4 w-full overflow-x-auto pb-1">
              {allGalleryImages.map((imgUrl, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImageIndex(idx)}
                  className={`w-16 h-16 rounded-xl border-2 overflow-hidden bg-zinc-50 shrink-0 transition-all ${
                    selectedImageIndex === idx ? 'border-red-600 ring-2 ring-red-600/30 scale-105' : 'border-zinc-200 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={imgUrl} alt={`Thumbnail ${idx}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-3 gap-3 w-full mt-6 pt-6 border-t border-zinc-100 text-center text-xs font-semibold text-zinc-600">
              <div className="flex flex-col items-center gap-1.5 p-2 bg-zinc-50 rounded-xl">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <span className="text-[11px]">100% Authentic</span>
              </div>
              <div className="flex flex-col items-center gap-1.5 p-2 bg-zinc-50 rounded-xl">
                <Truck className="w-5 h-5 text-red-600" />
                <span className="text-[11px]">Free Shipping</span>
              </div>
              <div className="flex flex-col items-center gap-1.5 p-2 bg-zinc-50 rounded-xl">
                <RotateCcw className="w-5 h-5 text-zinc-700" />
                <span className="text-[11px]">7 Days Return</span>
              </div>
            </div>

          </div>

          {/* Column 2: Details (4 Cols) */}
          <div className="lg:col-span-4 space-y-5">
            
            {/* Brand & Title */}
            <div>
              <span className="text-xs uppercase font-extrabold tracking-widest text-red-600 bg-red-50 px-3 py-1 rounded-full border border-red-200 inline-block mb-2">
                Brand: {product.brand}
              </span>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-zinc-900 leading-snug">
                {product.title}
              </h1>
            </div>

            {/* Rating Stars & Customer Count */}
            <div className="flex items-center gap-2 border-b border-zinc-100 pb-4">
              <div className="flex items-center text-amber-500 font-extrabold text-sm gap-1">
                <span>{product.rating}</span>
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-current text-amber-500" />
                  ))}
                </div>
              </div>
              <span className="text-xs font-semibold text-zinc-500">
                ({product.reviewsCount} verified reviews)
              </span>
            </div>

            {/* Price Section with Offer MRP */}
            <div className="space-y-1">
              <div className="flex items-baseline gap-3 flex-wrap">
                <span className="text-3xl font-black text-zinc-900">
                  {formatPrice(product.price)}
                </span>
                <span className="text-base font-semibold text-zinc-400 line-through">
                  {formatPrice(product.originalPrice || Math.round(product.price * 1.25))}
                </span>
                <span className="text-xs font-extrabold text-red-600 bg-red-50 px-2 py-0.5 rounded">
                  Save {formatPrice((product.originalPrice || Math.round(product.price * 1.25)) - product.price)} ({Math.round((((product.originalPrice || Math.round(product.price * 1.25)) - product.price) / (product.originalPrice || Math.round(product.price * 1.25))) * 100)}% OFF)
                </span>
              </div>
              <p className="text-[11px] font-medium text-zinc-500">Inclusive of all taxes & free express shipping across India</p>
            </div>

            {/* Dynamic Color Swatch Selector */}
            <div className="space-y-2 border-t border-zinc-100 pt-4">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold uppercase tracking-wider text-zinc-700 block">
                  Select Colorway:
                </span>
                {mappedVariant && (
                  <span className="text-xs font-bold text-red-600">{mappedVariant.colorName}</span>
                )}
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                {product.colors.map((hex, i) => {
                  const variant = product.colorVariants?.find(v => v.colorHex.toLowerCase() === hex.toLowerCase());
                  return (
                    <button
                      key={i}
                      onClick={() => handleColorClick(hex)}
                      title={variant ? `${variant.colorName} (Switches Image)` : hex}
                      className={`w-9 h-9 rounded-full border-2 transition-all flex items-center justify-center ${
                        activeColor === hex 
                          ? 'border-zinc-950 ring-2 ring-red-600 ring-offset-1 scale-110 shadow-md' 
                          : 'border-zinc-300 hover:scale-105'
                      }`}
                      style={{ backgroundColor: hex }}
                    >
                      {activeColor === hex && (
                        <Check className={`w-4 h-4 ${hex === '#FFFFFF' || hex === '#E5E7EB' ? 'text-zinc-950' : 'text-white'}`} />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Dynamic Shoe Size Grid */}
            <div className="space-y-2 border-t border-zinc-100 pt-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-zinc-700 block">
                  Select Shoe Size:
                </span>
                <span className="text-xs font-bold text-red-600">Standard India Fitting</span>
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                {shoeSizes.map(sz => (
                  <button
                    key={sz}
                    onClick={() => setSelectedSize(sz)}
                    className={`py-2 text-xs font-bold rounded-xl border transition-all ${
                      currentSize === sz
                        ? 'bg-zinc-950 text-white border-zinc-950 shadow-xs'
                        : 'bg-white text-zinc-700 border-zinc-200 hover:border-zinc-400'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </div>

            {/* Highlights */}
            <div className="border-t border-zinc-100 pt-4 space-y-2 text-xs text-zinc-700">
              <span className="font-bold text-zinc-900 uppercase block mb-1">Key Features:</span>
              <ul className="space-y-1.5 list-disc pl-4 leading-relaxed">
                <li>Oversized chunky streetwear sole engineered for maximum comfort.</li>
                <li>Premium full-grain leather & suede construction.</li>
                <li>Authentic Hawix street certification.</li>
              </ul>
            </div>

          </div>

          {/* Column 3: Buy Box (3 Cols) */}
          <div className="lg:col-span-3">
            <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-5 space-y-4 shadow-xs sticky top-24">
              
              <div>
                <span className="text-2xl font-black text-zinc-900 block">
                  {formatPrice(product.price * quantity)}
                </span>
                <span className="text-xs font-extrabold text-emerald-600 flex items-center gap-1 mt-1">
                  <Check className="w-4 h-4" />
                  In Stock ({product.stock} available)
                </span>
              </div>

              {/* Delivery info */}
              <div className="space-y-1.5 text-xs text-zinc-600 border-t border-zinc-200 pt-3">
                <div className="flex items-start gap-2">
                  <Truck className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-zinc-900 block">FREE Express Shipping</span>
                    <span>Expected delivery in 2-4 business days</span>
                  </div>
                </div>
              </div>

              {/* Quantity Selector */}
              <div className="border-t border-zinc-200 pt-3">
                <label className="text-xs font-bold text-zinc-700 block mb-1">Quantity:</label>
                <select
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full py-2 px-3 bg-white border border-zinc-300 rounded-xl text-xs font-bold outline-none focus:border-zinc-900"
                >
                  {[1, 2, 3, 4, 5].map(n => (
                    <option key={n} value={n}>{n} pair{n > 1 ? 's' : ''}</option>
                  ))}
                </select>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-2">
                <button
                  onClick={() => addToCart(product, activeColor, quantity)}
                  className="w-full py-3 bg-zinc-950 hover:bg-zinc-800 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-2 shadow-md"
                >
                  <ShoppingBag className="w-4 h-4" />
                  Add to Cart
                </button>

                <button
                  onClick={handleBuyNow}
                  className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-colors shadow-md shadow-red-600/20 text-center"
                >
                  Buy Now
                </button>
              </div>

              {/* Security info */}
              <div className="border-t border-zinc-200 pt-3 text-[11px] text-zinc-500 space-y-1">
                <div className="flex justify-between">
                  <span>Category:</span>
                  <strong className="text-zinc-800">{product.category}</strong>
                </div>
                <div className="flex items-center gap-1 text-emerald-700 font-bold pt-1">
                  <Lock className="w-3 h-3" />
                  <span>Verified 256-Bit SSL Checkout</span>
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* Reviews & Description Section */}
        <div className="mt-8 bg-white p-6 sm:p-8 rounded-3xl border border-zinc-200 space-y-6">
          <div className="flex border-b border-zinc-200 gap-6 text-sm font-bold">
            <button
              onClick={() => setActiveTab('overview')}
              className={`pb-3 border-b-2 transition-colors ${
                activeTab === 'overview' ? 'border-red-600 text-zinc-900 font-extrabold' : 'border-transparent text-zinc-500'
              }`}
            >
              Product Overview
            </button>
            <button
              onClick={() => setActiveTab('reviews')}
              className={`pb-3 border-b-2 transition-colors ${
                activeTab === 'reviews' ? 'border-red-600 text-zinc-900 font-extrabold' : 'border-transparent text-zinc-500'
              }`}
            >
              Customer Reviews ({product.reviewsCount})
            </button>
          </div>

          {activeTab === 'overview' && (
            <div className="space-y-4 text-xs sm:text-sm text-zinc-700 leading-relaxed max-w-3xl">
              <p>{product.description}</p>
              <p>
                Engineered with high precision and premium streetwear aesthetics, the {product.title} delivers ultimate style and bold presence.
              </p>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="space-y-6">
              <div className="flex items-center gap-6 p-4 bg-zinc-50 rounded-2xl border border-zinc-200">
                <div className="text-center">
                  <span className="text-4xl font-black text-zinc-900 block">{product.rating}</span>
                  <div className="flex text-amber-500 justify-center my-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                  <span className="text-xs text-zinc-500 font-medium">Out of 5 stars</span>
                </div>
              </div>

              <div className="space-y-4">
                <div className="p-4 border-b border-zinc-100 space-y-1 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-zinc-900">Ayaan A.</span>
                    <span className="text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded text-[10px]">Verified Customer</span>
                  </div>
                  <div className="flex text-amber-500">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-current" />
                    ))}
                  </div>
                  <p className="font-bold text-zinc-800 text-sm">Insane quality chunky shoes!</p>
                  <p className="text-zinc-600">The dynamic color switching and fit are accurate. Fast shipping!</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Related Products Section */}
        {relatedProducts.length > 0 && (
          <div className="mt-10">
            <h3 className="font-condensed text-3xl font-extrabold uppercase text-zinc-900 mb-6">
              You May Also Like
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6">
              {relatedProducts.map((rel) => (
                <div 
                  key={rel.id}
                  onClick={() => viewProductPage(rel)}
                  className="bg-white p-4 rounded-2xl border border-zinc-200 hover:shadow-lg transition-all cursor-pointer group"
                >
                  <img src={rel.image} alt={rel.title} className="w-full aspect-square object-cover rounded-xl bg-zinc-50 mb-3 group-hover:scale-105 transition-transform" />
                  <span className="text-[10px] uppercase font-bold text-zinc-400">{rel.brand}</span>
                  <h4 className="text-xs font-bold text-zinc-900 truncate group-hover:text-red-600">{rel.title}</h4>
                  <span className="text-sm font-extrabold text-zinc-900 block mt-1">{formatPrice(rel.price)}</span>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
