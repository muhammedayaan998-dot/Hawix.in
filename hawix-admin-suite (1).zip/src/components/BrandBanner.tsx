import React from 'react';
import { BRAND_LOGOS } from '../data/initialData';
import { useApp } from '../context/AppContext';

export const BrandBanner: React.FC = () => {
  const { setSelectedBrand, selectedBrand } = useApp();

  const handleBrandClick = (brandName: string) => {
    setSelectedBrand(selectedBrand === brandName ? 'All' : brandName);
    const elem = document.getElementById('best-sellers-section');
    if (elem) elem.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="bg-white border-b border-slate-200 py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title */}
        <h3 className="text-center text-xs font-bold uppercase tracking-widest text-slate-500 mb-8">
          Replacement Shoelaces for Popular Brands
        </h3>

        {/* Logos Marquee / Grid */}
        <div className="flex flex-wrap items-center justify-center gap-8 sm:gap-12 lg:gap-16 opacity-90">
          {BRAND_LOGOS.map((b) => {
            const isSelected = selectedBrand === b.name;
            return (
              <button
                key={b.name}
                onClick={() => handleBrandClick(b.name)}
                className={`p-2 transition-all transform hover:scale-110 flex items-center justify-center ${
                  isSelected ? 'scale-110 ring-2 ring-lime-400 rounded-lg bg-lime-50/50 p-3' : 'hover:opacity-100 opacity-70 grayscale hover:grayscale-0'
                }`}
                title={`Filter ${b.name} Laces`}
              >
                <img
                  src={b.logo}
                  alt={`${b.name} Shoelaces`}
                  className="h-7 sm:h-9 max-w-[100px] object-contain"
                />
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
