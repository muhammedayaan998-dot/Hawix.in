import React, { useState } from 'react';
import { INITIAL_NEWS } from '../data/initialData';
import { BookOpen, Clock, ArrowRight, X } from 'lucide-react';
import { NewsArticle } from '../types';

export const NewsSection: React.FC = () => {
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);

  const brandColors: Record<string, string> = {
    BROOKS: 'from-blue-600 to-indigo-800',
    ASICS: 'from-purple-500 to-indigo-600',
    HOKA: 'from-sky-400 to-blue-600'
  };

  return (
    <section id="news-section" className="py-12 bg-white border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <h2 className="font-condensed text-4xl sm:text-5xl font-extrabold uppercase tracking-tight text-slate-900 mb-8">
          NEWS & SNEAKER GUIDES
        </h2>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {INITIAL_NEWS.map((article) => {
            const gradient = brandColors[article.brand] || 'from-slate-800 to-black';
            return (
              <div 
                key={article.id}
                onClick={() => setSelectedArticle(article)}
                className="group flex flex-col bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer"
              >
                {/* Banner Graphic Header */}
                <div className={`h-48 sm:h-52 bg-gradient-to-tr ${gradient} relative flex items-center justify-center overflow-hidden p-6 text-white`}>
                  <div className="text-center z-10">
                    <span className="font-condensed text-5xl font-black tracking-tighter uppercase opacity-90 block drop-shadow-md">
                      {article.brand}
                    </span>
                    <span className="text-xs uppercase tracking-widest font-bold text-lime-300 bg-black/30 px-3 py-1 rounded-full backdrop-blur-xs inline-block mt-2">
                      running shoe guide
                    </span>
                  </div>
                  {/* Decorative background circle */}
                  <div className="absolute -bottom-10 -right-10 w-40 h-40 rounded-full bg-white/10 blur-xl group-hover:scale-125 transition-transform duration-500" />
                </div>

                {/* Body Content */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-slate-400 font-bold mb-2">
                      <span>{article.category}</span>
                      <span>·</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {article.readTime}
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-slate-900 group-hover:text-lime-600 transition-colors line-clamp-2">
                      {article.title}
                    </h3>

                    <p className="mt-2 text-xs text-slate-500 line-clamp-2">
                      {article.subtitle}
                    </p>
                  </div>

                  <div className="mt-6 flex items-center text-xs font-bold text-slate-900 group-hover:text-lime-600 gap-1.5">
                    <span>Read Article</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Article Detail Reader Modal */}
      {selectedArticle && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white max-w-2xl w-full rounded-2xl shadow-2xl p-6 sm:p-8 relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setSelectedArticle(null)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full"
            >
              <X className="w-6 h-6" />
            </button>

            <span className="text-xs uppercase font-extrabold text-lime-600 bg-lime-50 px-3 py-1 rounded-full">
              {selectedArticle.category}
            </span>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-3 mb-2">
              {selectedArticle.title}
            </h2>

            <p className="text-sm font-semibold text-slate-500 mb-6">
              {selectedArticle.subtitle}
            </p>

            <div className="space-y-4 text-slate-700 text-sm leading-relaxed border-t border-slate-100 pt-4">
              <p>
                Choosing the perfect pair of shoelaces for your {selectedArticle.brand} footwear ensures optimized lockdown, prevents heel slipping, and absorbs peak impact forces during intense activity.
              </p>
              <h4 className="font-bold text-slate-900 text-base">Key Lacing Recommendations:</h4>
              <ul className="list-disc pl-5 space-y-2">
                <li><strong>Heel Lock Loop:</strong> Use the extra top eyelet for a runner's knot to eliminate heel slip.</li>
                <li><strong>Flat 8mm Weave:</strong> Ideal for daily training, distributing pressure evenly across the instep.</li>
                <li><strong>Elastic Speed Laces:</strong> Perfect for triathlons and quick transition times without tying knots.</li>
              </ul>
              <p>
                Explore our full line of official Hawix.in replacement shoelaces engineered for performance, style, and durability.
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
