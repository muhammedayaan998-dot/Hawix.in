import React, { useState } from 'react';
import { X, Star, ShoppingBag, ShieldCheck, Truck, RefreshCw, Check } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ProductDetailModal: React.FC = () => {
  const { 
    selectedProductModal, 
    setSelectedProductModal, 
    formatPrice, 
    addToCart,
    setIsCartDrawerOpen
  } = useApp();

  const [selectedColor, setSelectedColor] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);

  if (!selectedProductModal) return null;

  const product = selectedProductModal;
  const activeColor = selectedColor || (product.colors && product.colors.length > 0 ? product.colors[0] : '#000000');

  const handleBuyNow = () => {
    addToCart(product, activeColor, quantity);
    setSelectedProductModal(null);
    setIsCartDrawerOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div 
        className="bg-white max-w-3xl w-full rounded-2xl shadow-2xl overflow-hidden border border-slate-100 relative flex flex-col md:flex-row max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={() => setSelectedProductModal(null)}
          className="absolute top-4 right-4 z-10 p-2 bg-white/80 hover:bg-white text-slate-600 rounded-full shadow-md backdrop-blur-xs transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Product Image Column */}
        <div className="w-full md:w-1/2 bg-slate-100 relative min-h-[300px] flex items-center justify-center p-6">
          <img
            src={product.image}
            alt={product.title}
            className="w-full h-auto max-h-[380px] object-cover rounded-xl shadow-md"
          />
          {product.isBestSeller && (
            <span className="absolute top-4 left-4 bg-lime-400 text-slate-950 text-xs font-black uppercase px-3 py-1 rounded-sm tracking-wider shadow-sm">
              Best Seller
            </span>
          )}
        </div>

        {/* Product Information Column */}
        <div className="w-full md:w-1/2 p-6 sm:p-8 flex flex-col justify-between">
          <div>
            {/* Category & Brand */}
            <div className="flex items-center justify-between text-xs text-slate-400 font-bold uppercase tracking-wider mb-2">
              <span>{product.brand} · {product.category}</span>
              <span className="flex items-center gap-1 text-amber-500 font-bold">
                <Star className="w-3.5 h-3.5 fill-current" />
                {product.rating} ({product.reviewsCount} reviews)
              </span>
            </div>

            {/* Title */}
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 leading-snug">
              {product.title}
            </h2>

            {/* Price */}
            <div className="flex items-center gap-3 mt-3 mb-6">
              <span className="text-2xl font-black text-slate-900">
                {formatPrice(product.price)}
              </span>
              {product.originalPrice && (
                <span className="text-sm font-semibold text-slate-400 line-through">
                  {formatPrice(product.originalPrice)}
                </span>
              )}
              <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-md ml-auto">
                In Stock ({product.stock} available)
              </span>
            </div>

            {/* Color Swatch Picker */}
            <div className="mb-6">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-600 block mb-2">
                Select Color:
              </span>
              <div className="flex items-center gap-2 flex-wrap">
                {product.colors.map((colorHex, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedColor(colorHex)}
                    className={`w-7 h-7 rounded-full border-2 transition-all flex items-center justify-center ${
                      activeColor === colorHex 
                        ? 'border-slate-900 scale-110 shadow-md ring-2 ring-lime-400 ring-offset-1' 
                        : 'border-slate-300 hover:scale-105'
                    }`}
                    style={{ backgroundColor: colorHex }}
                    title={`Color option ${i + 1}`}
                  >
                    {activeColor === colorHex && (
                      <Check className={`w-3.5 h-3.5 ${colorHex === '#FFFFFF' || colorHex === '#E5E7EB' ? 'text-slate-900' : 'text-white'}`} />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity Selector */}
            <div className="mb-6">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-600 block mb-2">
                Quantity:
              </span>
              <div className="inline-flex items-center border border-slate-300 rounded-lg overflow-hidden bg-slate-50">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3.5 py-2 text-slate-600 hover:bg-slate-200 font-bold transition-colors"
                >
                  -
                </button>
                <span className="px-4 py-2 text-sm font-bold text-slate-900">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3.5 py-2 text-slate-600 hover:bg-slate-200 font-bold transition-colors"
                >
                  +
                </button>
              </div>
            </div>

            {/* Description */}
            <p className="text-xs text-slate-600 leading-relaxed mb-6">
              {product.description}
            </p>
          </div>

          {/* Actions & Value Props */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <button
                onClick={() => {
                  addToCart(product, activeColor, quantity);
                  setSelectedProductModal(null);
                }}
                className="flex-1 py-3 px-4 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-2 shadow-md"
              >
                <ShoppingBag className="w-4 h-4" />
                Add to Cart
              </button>
              <button
                onClick={handleBuyNow}
                className="flex-1 py-3 px-4 bg-lime-400 hover:bg-lime-500 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-xl transition-colors text-center shadow-md shadow-lime-400/20"
              >
                Buy Now
              </button>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-3 gap-2 pt-4 border-t border-slate-100 text-[10px] text-slate-500 font-medium text-center">
              <div className="flex flex-col items-center gap-1">
                <Truck className="w-4 h-4 text-slate-700" />
                <span>Fast Shipping</span>
              </div>
              <div className="flex flex-col items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-slate-700" />
                <span>100% Authentic</span>
              </div>
              <div className="flex flex-col items-center gap-1">
                <RefreshCw className="w-4 h-4 text-slate-700" />
                <span>Easy Returns</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
