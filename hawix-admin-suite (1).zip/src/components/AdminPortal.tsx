import React, { useState } from 'react';
import { 
  X, 
  Plus, 
  Edit, 
  Trash2, 
  Save, 
  Package, 
  Layout, 
  ShoppingBag, 
  MessageSquare, 
  ShieldCheck,
  Image as ImageIcon,
  Grid,
  LogOut,
  Palette
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Product, CategoryItem, ColorVariant } from '../types';

export const AdminPortal: React.FC = () => {
  const { 
    isAdminPortalOpen, 
    setIsAdminPortalOpen, 
    products, 
    categories,
    siteConfig, 
    orders, 
    enquiries, 
    addProduct, 
    updateProduct, 
    deleteProduct,
    addCategory,
    updateCategory,
    deleteCategory, 
    updateSiteConfig,
    updateOrderStatus,
    logout,
    formatPrice 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'products' | 'categories' | 'website' | 'orders' | 'enquiries'>('products');
  
  // Product Edit Form state
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [isAddingNew, setIsAddingNew] = useState<boolean>(false);

  // Category Edit Form state
  const [editingCategory, setEditingCategory] = useState<Partial<CategoryItem> | null>(null);
  const [isAddingCategory, setIsAddingCategory] = useState<boolean>(false);

  // Color Variant temp input in product modal
  const [newColorHex, setNewColorHex] = useState<string>('#10B981');
  const [newColorName, setNewColorName] = useState<string>('Green');
  const [newColorImage, setNewColorImage] = useState<string>('');

  // Site Config Edit Form state
  const [heroTitle, setHeroTitle] = useState<string>(siteConfig.heroTitle);
  const [heroSubtitle, setHeroSubtitle] = useState<string>(siteConfig.heroSubtitle);
  const [heroCtaText, setHeroCtaText] = useState<string>(siteConfig.heroCtaText);
  const [heroImage, setHeroImage] = useState<string>(siteConfig.heroImage);
  const [promoTitle, setPromoTitle] = useState<string>(siteConfig.promoTitle);
  const [promoSubtitle, setPromoSubtitle] = useState<string>(siteConfig.promoSubtitle);
  const [promoCtaText, setPromoCtaText] = useState<string>(siteConfig.promoCtaText);
  const [promoImage, setPromoImage] = useState<string>(siteConfig.promoImage);
  const [announcementText, setAnnouncementText] = useState<string>(siteConfig.announcementText);
  const [isSavingConfig, setIsSavingConfig] = useState<boolean>(false);

  if (!isAdminPortalOpen) return null;

  const ALL_SIZES = ['India 6', 'India 7', 'India 8', 'India 9', 'India 10', 'India 11', 'India 12'];

  // Handle Save Product
  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct?.title || !editingProduct?.price || editingProduct.stock === undefined) return;

    const defaultCat = categories.length > 0 ? categories[0].name : 'Chunky Shoes';

    if (isAddingNew) {
      const primaryImage = editingProduct.image || (editingProduct.images && editingProduct.images[0]) || (editingProduct.colorVariants && editingProduct.colorVariants[0]?.image) || 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800';
      const galleryImgs = editingProduct.images && editingProduct.images.length > 0 
        ? editingProduct.images 
        : [primaryImage];

      await addProduct({
        title: editingProduct.title,
        price: Number(editingProduct.price),
        originalPrice: editingProduct.originalPrice ? Number(editingProduct.originalPrice) : Math.round(Number(editingProduct.price) * 1.25),
        stock: Number(editingProduct.stock),
        image: primaryImage,
        images: Array.from(new Set(galleryImgs.filter(Boolean))),
        colorVariants: editingProduct.colorVariants || [],
        category: editingProduct.category || defaultCat,
        brand: editingProduct.brand || 'Hawix',
        rating: editingProduct.rating || 5.0,
        reviewsCount: editingProduct.reviewsCount || 1,
        colors: editingProduct.colors && editingProduct.colors.length > 0 ? editingProduct.colors : (editingProduct.colorVariants?.map(v => v.colorHex) || ['#111827']),
        availableSizes: editingProduct.availableSizes && editingProduct.availableSizes.length > 0 ? editingProduct.availableSizes : ALL_SIZES,
        isBestSeller: Boolean(editingProduct.isBestSeller),
        isNewArrival: Boolean(editingProduct.isNewArrival),
        description: editingProduct.description || 'Premium chunky footwear by Hawix.in.'
      });
    } else if (editingProduct.id) {
      await updateProduct(editingProduct.id, editingProduct);
    }

    setEditingProduct(null);
    setIsAddingNew(false);
  };

  // Handle Save Category
  const handleCategorySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory?.name) return;

    if (isAddingCategory) {
      await addCategory({
        name: editingCategory.name,
        image: editingCategory.image || 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
        description: editingCategory.description || ''
      });
    } else if (editingCategory.id) {
      await updateCategory(editingCategory.id, editingCategory);
    }

    setEditingCategory(null);
    setIsAddingCategory(false);
  };

  // Handle Save Website Config
  const handleSaveWebsiteConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingConfig(true);
    await updateSiteConfig({
      heroTitle,
      heroSubtitle,
      heroCtaText,
      heroImage,
      promoTitle,
      promoSubtitle,
      promoCtaText,
      promoImage,
      announcementText
    });
    setIsSavingConfig(false);
  };

  const presetImages = [
    'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
    'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&q=80&w=800',
    'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&q=80&w=800',
    'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&q=80&w=800',
    'https://images.unsplash.com/photo-1597045566677-8cf032ed6634?auto=format&fit=crop&q=80&w=800',
    'https://images.unsplash.com/photo-1516478177764-9fe5bd7e9717?auto=format&fit=crop&q=80&w=800'
  ];

  const handleAddColorVariant = () => {
    if (!newColorName || !newColorHex || !editingProduct) return;
    const currentVariants = editingProduct.colorVariants || [];
    const mainImg = newColorImage || editingProduct.image || presetImages[0];
    const updatedVariants: ColorVariant[] = [
      ...currentVariants,
      { 
        colorHex: newColorHex, 
        colorName: newColorName, 
        image: mainImg,
        images: [mainImg] 
      }
    ];
    
    // Also append color hex to colors list if not present
    const currentColors = editingProduct.colors || [];
    const updatedColors = currentColors.includes(newColorHex) ? currentColors : [...currentColors, newColorHex];

    setEditingProduct({
      ...editingProduct,
      colorVariants: updatedVariants,
      colors: updatedColors
    });

    setNewColorName('');
    setNewColorImage('');
  };

  const handleAddImageToVariant = (variantIdx: number, imgUrl: string) => {
    if (!editingProduct || !editingProduct.colorVariants || !imgUrl) return;
    const updatedVariants = [...editingProduct.colorVariants];
    const targetVariant = { ...updatedVariants[variantIdx] };
    const currentImgs = targetVariant.images || (targetVariant.image ? [targetVariant.image] : []);
    targetVariant.images = [...currentImgs, imgUrl];
    if (!targetVariant.image) targetVariant.image = imgUrl;
    updatedVariants[variantIdx] = targetVariant;

    setEditingProduct({
      ...editingProduct,
      colorVariants: updatedVariants
    });
  };

  const handleRemoveImageFromVariant = (variantIdx: number, imgIdx: number) => {
    if (!editingProduct || !editingProduct.colorVariants) return;
    const updatedVariants = [...editingProduct.colorVariants];
    const targetVariant = { ...updatedVariants[variantIdx] };
    const currentImgs = targetVariant.images || [];
    const updatedImgs = currentImgs.filter((_, i) => i !== imgIdx);
    targetVariant.images = updatedImgs;
    if (updatedImgs.length > 0) {
      targetVariant.image = updatedImgs[0];
    }
    updatedVariants[variantIdx] = targetVariant;

    setEditingProduct({
      ...editingProduct,
      colorVariants: updatedVariants
    });
  };

  const handleRemoveColorVariant = (idx: number) => {
    if (!editingProduct || !editingProduct.colorVariants) return;
    const updatedVariants = editingProduct.colorVariants.filter((_, i) => i !== idx);
    setEditingProduct({
      ...editingProduct,
      colorVariants: updatedVariants
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-6 animate-in fade-in duration-200">
      <div 
        className="bg-white w-full max-w-6xl h-[92vh] rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-zinc-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="p-4 sm:p-6 bg-zinc-950 text-white flex items-center justify-between border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center font-black">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-condensed text-2xl font-bold uppercase tracking-wide flex items-center gap-2">
                HAWIX<span className="text-red-600">.IN</span> ADMIN DASHBOARD
              </h2>
              <p className="text-[11px] text-zinc-400 font-medium">Logged in as Administrator (muhammedayaan119@gmail.com)</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => { logout(); setIsAdminPortalOpen(false); }}
              className="px-3 py-1.5 bg-zinc-800 hover:bg-red-600 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              Sign Out
            </button>
            <button
              onClick={() => setIsAdminPortalOpen(false)}
              className="p-2 text-zinc-400 hover:text-white rounded-lg"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-zinc-200 bg-zinc-50 px-6 pt-2 gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('products')}
            className={`px-4 py-3 text-xs font-bold rounded-t-xl transition-all flex items-center gap-2 ${
              activeTab === 'products' ? 'bg-white text-zinc-900 shadow-xs border-t-2 border-red-600' : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            <Package className="w-4 h-4 text-red-600" />
            Products & Inventory ({products.length})
          </button>

          <button
            onClick={() => setActiveTab('categories')}
            className={`px-4 py-3 text-xs font-bold rounded-t-xl transition-all flex items-center gap-2 ${
              activeTab === 'categories' ? 'bg-white text-zinc-900 shadow-xs border-t-2 border-red-600' : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            <Grid className="w-4 h-4 text-red-600" />
            Categories ({categories.length})
          </button>

          <button
            onClick={() => setActiveTab('website')}
            className={`px-4 py-3 text-xs font-bold rounded-t-xl transition-all flex items-center gap-2 ${
              activeTab === 'website' ? 'bg-white text-zinc-900 shadow-xs border-t-2 border-red-600' : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            <Layout className="w-4 h-4 text-red-600" />
            Website Customization
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-3 text-xs font-bold rounded-t-xl transition-all flex items-center gap-2 ${
              activeTab === 'orders' ? 'bg-white text-zinc-900 shadow-xs border-t-2 border-red-600' : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            <ShoppingBag className="w-4 h-4 text-red-600" />
            Customer Orders ({orders.length})
          </button>

          <button
            onClick={() => setActiveTab('enquiries')}
            className={`px-4 py-3 text-xs font-bold rounded-t-xl transition-all flex items-center gap-2 ${
              activeTab === 'enquiries' ? 'bg-white text-zinc-900 shadow-xs border-t-2 border-red-600' : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            <MessageSquare className="w-4 h-4 text-red-600" />
            Customer Inquiries ({enquiries.length})
          </button>
        </div>

        {/* Tab Content Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-zinc-50/50">
          
          {/* TAB 1: PRODUCTS & INVENTORY */}
          {activeTab === 'products' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-bold text-zinc-900">Products Catalog</h3>
                  <p className="text-xs text-zinc-500">Manage chunky shoe inventory, available sizes, custom color variant images, and categories.</p>
                </div>
                <button
                  onClick={() => {
                    setEditingProduct({
                      title: '',
                      price: 4999,
                      originalPrice: 6999,
                      stock: 25,
                      image: '',
                      images: [],
                      category: categories.length > 0 ? categories[0].name : 'Chunky Shoes',
                      brand: 'Hawix',
                      colors: [],
                      availableSizes: ALL_SIZES,
                      isBestSeller: true,
                      isNewArrival: true,
                      description: '',
                      colorVariants: []
                    });
                    setIsAddingNew(true);
                  }}
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-md transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  Add New Product
                </button>
              </div>

              {/* Products Table */}
              <div className="bg-white rounded-2xl border border-zinc-200 overflow-hidden shadow-xs">
                <table className="w-full text-left border-collapse text-xs">
                  <thead className="bg-zinc-100 text-zinc-700 font-bold uppercase tracking-wider text-[11px] border-b border-zinc-200">
                    <tr>
                      <th className="p-3">Product</th>
                      <th className="p-3">Category / Brand</th>
                      <th className="p-3">Color Variants</th>
                      <th className="p-3">Price</th>
                      <th className="p-3">Stock Status</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-100 font-medium">
                    {products.map((p) => (
                      <tr key={p.id} className="hover:bg-zinc-50 transition-colors">
                        <td className="p-3 flex items-center gap-3">
                          <img src={p.image} alt={p.title} className="w-12 h-12 object-cover rounded-lg bg-zinc-100 shrink-0" />
                          <div>
                            <p className="font-bold text-zinc-900">{p.title}</p>
                            <p className="text-[11px] text-zinc-400 line-clamp-1">{p.description}</p>
                          </div>
                        </td>
                        <td className="p-3 text-zinc-600">
                          <span className="px-2 py-0.5 bg-zinc-100 rounded text-[11px] font-bold text-zinc-700">{p.brand}</span>
                          <span className="ml-1 text-[11px] text-zinc-400">· {p.category}</span>
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-1">
                            {p.colorVariants && p.colorVariants.length > 0 ? (
                              p.colorVariants.map((cv, idx) => (
                                <span
                                  key={idx}
                                  title={`${cv.colorName} mapped image`}
                                  className="w-4 h-4 rounded-full border border-zinc-300 shadow-xs inline-block"
                                  style={{ backgroundColor: cv.colorHex }}
                                />
                              ))
                            ) : (
                              p.colors?.map((c, idx) => (
                                <span
                                  key={idx}
                                  className="w-4 h-4 rounded-full border border-zinc-300 shadow-xs inline-block"
                                  style={{ backgroundColor: c }}
                                />
                              ))
                            )}
                          </div>
                        </td>
                        <td className="p-3 font-extrabold text-zinc-900">
                          {formatPrice(p.price)}
                        </td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${p.stock > 20 ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>
                            {p.stock} in stock
                          </span>
                        </td>
                        <td className="p-3 text-right space-x-2">
                          <button
                            onClick={() => { setEditingProduct(p); setIsAddingNew(false); }}
                            className="p-1.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 rounded-md"
                            title="Edit Product"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => deleteProduct(p.id)}
                            className="p-1.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-md"
                            title="Delete Product"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: CATEGORY MANAGEMENT */}
          {activeTab === 'categories' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-bold text-zinc-900">Shoe Categories</h3>
                  <p className="text-xs text-zinc-500">Add, edit, or remove categories and assign banner images for product filtering.</p>
                </div>
                <button
                  onClick={() => {
                    setEditingCategory({
                      name: '',
                      image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
                      description: ''
                    });
                    setIsAddingCategory(true);
                  }}
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-md transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  Add New Category
                </button>
              </div>

              {/* Categories Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {categories.map((cat) => (
                  <div key={cat.id} className="bg-white rounded-2xl border border-zinc-200 p-4 shadow-xs flex flex-col justify-between">
                    <div className="flex items-start gap-3">
                      <img src={cat.image} alt={cat.name} className="w-16 h-16 object-cover rounded-xl bg-zinc-100 shrink-0" />
                      <div className="flex-1">
                        <h4 className="font-bold text-sm text-zinc-900">{cat.name}</h4>
                        <p className="text-xs text-zinc-500 line-clamp-2 mt-0.5">{cat.description || 'No description provided.'}</p>
                        <p className="text-[11px] font-bold text-red-600 mt-2">
                          {products.filter(p => p.category === cat.name).length} Products assigned
                        </p>
                      </div>
                    </div>
                    <div className="flex justify-end gap-2 pt-3 border-t border-zinc-100 mt-3">
                      <button
                        onClick={() => { setEditingCategory(cat); setIsAddingCategory(false); }}
                        className="px-3 py-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 text-xs font-bold rounded-lg flex items-center gap-1"
                      >
                        <Edit className="w-3.5 h-3.5" /> Edit
                      </button>
                      <button
                        onClick={() => deleteCategory(cat.id)}
                        className="px-3 py-1 bg-red-50 hover:bg-red-100 text-red-600 text-xs font-bold rounded-lg flex items-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: WEBSITE CUSTOMIZATION */}
          {activeTab === 'website' && (
            <form onSubmit={handleSaveWebsiteConfig} className="max-w-4xl space-y-8 bg-white p-6 sm:p-8 rounded-2xl border border-zinc-200">
              <div>
                <h3 className="text-lg font-bold text-zinc-900 mb-1">Website Hero & Banners Customizer</h3>
                <p className="text-xs text-zinc-500">Update the hero image, headlines, promo banners, and top announcement text in real-time across all devices.</p>
              </div>

              {/* Top Announcement Bar */}
              <div className="p-4 bg-zinc-50 rounded-xl border border-zinc-200 space-y-2">
                <label className="text-xs font-bold text-zinc-800 block">Top Announcement Bar Text</label>
                <input
                  type="text"
                  value={announcementText}
                  onChange={(e) => setAnnouncementText(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
                />
              </div>

              {/* Hero Section Customization */}
              <div className="p-5 bg-zinc-50 rounded-xl border border-zinc-200 space-y-4">
                <h4 className="text-xs font-extrabold uppercase text-zinc-800 tracking-wider">Hero Section Banner</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-zinc-700 block mb-1">Hero Title (Main Heading)</label>
                    <input
                      type="text"
                      value={heroTitle}
                      onChange={(e) => setHeroTitle(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600 font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-zinc-700 block mb-1">Hero Subtitle</label>
                    <input
                      type="text"
                      value={heroSubtitle}
                      onChange={(e) => setHeroSubtitle(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-zinc-700 block mb-1">Hero CTA Button Text</label>
                    <input
                      type="text"
                      value={heroCtaText}
                      onChange={(e) => setHeroCtaText(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-zinc-700 block mb-1">Hero Image File Upload & URL</label>
                    <div className="flex items-center gap-2 mb-2">
                      {heroImage && (
                        <img src={heroImage} alt="Hero Preview" className="w-12 h-10 object-cover rounded border border-zinc-300 shrink-0" />
                      )}
                      <label className="px-3 py-1.5 bg-zinc-950 hover:bg-zinc-800 text-white text-xs font-bold rounded-lg cursor-pointer inline-flex items-center gap-1.5 shadow-xs whitespace-nowrap">
                        <ImageIcon className="w-3.5 h-3.5" />
                        Upload Image File
                        <input 
                          type="file" 
                          accept="image/*" 
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onloadend = () => {
                                if (typeof reader.result === 'string') {
                                  setHeroImage(reader.result);
                                }
                              };
                              reader.readAsDataURL(file);
                            }
                          }} 
                          className="hidden" 
                        />
                      </label>
                    </div>
                    <input
                      type="text"
                      value={heroImage}
                      onChange={(e) => setHeroImage(e.target.value)}
                      placeholder="Or paste Hero Image URL (https://...)"
                      className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600 bg-white"
                    />
                  </div>
                </div>

                {/* Image Presets Selector */}
                <div>
                  <span className="text-[11px] font-bold text-zinc-500 block mb-2">Or select from image presets:</span>
                  <div className="flex gap-2 overflow-x-auto pb-1">
                    {presetImages.map((url, idx) => (
                      <img
                        key={idx}
                        src={url}
                        alt="Preset"
                        onClick={() => setHeroImage(url)}
                        className={`w-16 h-12 object-cover rounded-md cursor-pointer border-2 transition-all ${
                          heroImage === url ? 'border-red-600 scale-105' : 'border-zinc-200 opacity-70'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Promo Banner Customization */}
              <div className="p-5 bg-zinc-50 rounded-xl border border-zinc-200 space-y-4">
                <h4 className="text-xs font-extrabold uppercase text-zinc-800 tracking-wider">Custom Promo Banner</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-zinc-700 block mb-1">Promo Title</label>
                    <input
                      type="text"
                      value={promoTitle}
                      onChange={(e) => setPromoTitle(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600 font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-zinc-700 block mb-1">Promo Subtitle</label>
                    <input
                      type="text"
                      value={promoSubtitle}
                      onChange={(e) => setPromoSubtitle(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-zinc-700 block mb-1">Promo CTA Button Text</label>
                    <input
                      type="text"
                      value={promoCtaText}
                      onChange={(e) => setPromoCtaText(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-zinc-700 block mb-1">Promo Image File Upload & URL</label>
                    <div className="flex items-center gap-2 mb-2">
                      {promoImage && (
                        <img src={promoImage} alt="Promo Preview" className="w-12 h-10 object-cover rounded border border-zinc-300 shrink-0" />
                      )}
                      <label className="px-3 py-1.5 bg-zinc-950 hover:bg-zinc-800 text-white text-xs font-bold rounded-lg cursor-pointer inline-flex items-center gap-1.5 shadow-xs whitespace-nowrap">
                        <ImageIcon className="w-3.5 h-3.5" />
                        Upload Image File
                        <input 
                          type="file" 
                          accept="image/*" 
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onloadend = () => {
                                if (typeof reader.result === 'string') {
                                  setPromoImage(reader.result);
                                }
                              };
                              reader.readAsDataURL(file);
                            }
                          }} 
                          className="hidden" 
                        />
                      </label>
                    </div>
                    <input
                      type="text"
                      value={promoImage}
                      onChange={(e) => setPromoImage(e.target.value)}
                      placeholder="Or paste Promo Image URL (https://...)"
                      className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600 bg-white"
                    />
                  </div>
                </div>

                {/* Promo Presets Selector */}
                <div>
                  <span className="text-[11px] font-bold text-zinc-500 block mb-2">Or select from image presets:</span>
                  <div className="flex gap-2 overflow-x-auto pb-1">
                    {presetImages.map((url, idx) => (
                      <img
                        key={idx}
                        src={url}
                        alt="Preset"
                        onClick={() => setPromoImage(url)}
                        className={`w-16 h-12 object-cover rounded-md cursor-pointer border-2 transition-all ${
                          promoImage === url ? 'border-red-600 scale-105' : 'border-zinc-200 opacity-70'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSavingConfig}
                className="px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-colors shadow-md flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                {isSavingConfig ? 'Saving Changes...' : 'Save & Deploy Customizations'}
              </button>
            </form>
          )}

          {/* TAB 4: CUSTOMER ORDERS */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-bold text-zinc-900">Customer Orders</h3>
                <p className="text-xs text-zinc-500">Manage customer shoe orders submitted via checkout.</p>
              </div>

              {orders.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-2xl border border-zinc-200">
                  <p className="text-sm font-bold text-zinc-700">No orders placed yet</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {orders.map((o) => (
                    <div key={o.id} className="bg-white p-5 rounded-2xl border border-zinc-200 shadow-xs flex flex-col sm:flex-row justify-between gap-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-zinc-900">Order #{o.id.slice(-6).toUpperCase()}</span>
                          <span className="text-xs text-zinc-400">· {new Date(o.createdAt).toLocaleDateString()}</span>
                        </div>
                        <p className="text-xs text-zinc-600"><strong>Customer:</strong> {o.customerName} ({o.customerEmail})</p>
                        <p className="text-xs text-zinc-600"><strong>Address:</strong> {o.address}</p>
                        <div className="pt-2 flex gap-2 flex-wrap">
                          {o.items?.map((item, i) => (
                            <span key={i} className="text-[11px] bg-zinc-100 text-zinc-700 px-2 py-0.5 rounded font-medium">
                              {item.title} (x{item.quantity}) {item.selectedSize ? `Size: ${item.selectedSize}` : ''}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="flex flex-col items-end justify-between">
                        <span className="text-base font-black text-zinc-900">{formatPrice(o.totalAmount)}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-zinc-500">Status:</span>
                          <select
                            value={o.status}
                            onChange={(e) => updateOrderStatus(o.id, e.target.value as any)}
                            className="text-xs font-bold border border-zinc-300 rounded-md px-2 py-1 outline-none bg-zinc-50"
                          >
                            <option value="pending">Pending</option>
                            <option value="processing">Processing</option>
                            <option value="shipped">Shipped</option>
                            <option value="delivered">Delivered</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 5: CUSTOMER INQUIRIES */}
          {activeTab === 'enquiries' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-bold text-zinc-900">Customer Messages & Custom Requests</h3>
                <p className="text-xs text-zinc-500">Inquiries submitted via contact modal.</p>
              </div>

              {enquiries.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-2xl border border-zinc-200">
                  <p className="text-sm font-bold text-zinc-700">No customer inquiries yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {enquiries.map((enq) => (
                    <div key={enq.id} className="bg-white p-4 rounded-xl border border-zinc-200 shadow-xs space-y-1">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-bold text-zinc-900">{enq.name} ({enq.email})</span>
                        <span className="text-zinc-400">{new Date(enq.createdAt).toLocaleString()}</span>
                      </div>
                      <p className="text-xs font-bold text-red-600">{enq.subject}</p>
                      <p className="text-xs text-zinc-600 bg-zinc-50 p-2.5 rounded-lg border border-zinc-100">{enq.message}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>
      </div>

      {/* Edit / Add Category Sub-Modal */}
      {editingCategory && (
        <div className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
          <form 
            onSubmit={handleCategorySubmit}
            className="bg-white max-w-lg w-full rounded-2xl shadow-2xl p-6 space-y-4"
          >
            <div className="flex justify-between items-center border-b pb-3">
              <h3 className="font-bold text-zinc-900 text-base">
                {isAddingCategory ? 'Add New Category' : 'Edit Category'}
              </h3>
              <button type="button" onClick={() => setEditingCategory(null)} className="text-zinc-400 hover:text-zinc-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-700 block mb-1">Category Name *</label>
              <input
                type="text"
                required
                value={editingCategory.name || ''}
                onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })}
                placeholder="e.g. Chunky Shoes, Retro Sneakers..."
                className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-700 block mb-1">Category Image URL / Upload *</label>
              <div className="flex items-center gap-3 mb-2">
                {editingCategory.image && (
                  <img src={editingCategory.image} alt="Preview" className="w-12 h-12 object-cover rounded-lg border shrink-0" />
                )}
                <label className="px-3 py-1.5 bg-zinc-900 text-white text-xs font-bold rounded-lg cursor-pointer inline-flex items-center gap-1.5">
                  <ImageIcon className="w-3.5 h-3.5" />
                  Choose Image File
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onloadend = () => {
                          if (typeof reader.result === 'string') {
                            setEditingCategory({ ...editingCategory, image: reader.result });
                          }
                        };
                        reader.readAsDataURL(file);
                      }
                    }} 
                    className="hidden" 
                  />
                </label>
              </div>
              <input
                type="text"
                value={editingCategory.image || ''}
                onChange={(e) => setEditingCategory({ ...editingCategory, image: e.target.value })}
                placeholder="Image URL (https://...)"
                className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-700 block mb-1">Category Description</label>
              <textarea
                rows={2}
                value={editingCategory.description || ''}
                onChange={(e) => setEditingCategory({ ...editingCategory, description: e.target.value })}
                placeholder="Brief description of this shoe collection..."
                className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600 resize-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t">
              <button
                type="button"
                onClick={() => setEditingCategory(null)}
                className="px-4 py-2 bg-zinc-100 text-zinc-700 text-xs font-bold rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-red-600 text-white text-xs font-bold rounded-lg hover:bg-red-700 transition-colors"
              >
                Save Category
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Edit / Add Product Sub-Modal */}
      {editingProduct && (
        <div className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
          <form 
            onSubmit={handleProductSubmit}
            className="bg-white max-w-2xl w-full rounded-2xl shadow-2xl p-6 space-y-4 max-h-[88vh] overflow-y-auto"
          >
            <div className="flex justify-between items-center border-b pb-3">
              <h3 className="font-bold text-zinc-900 text-base">
                {isAddingNew ? 'Add New Shoe Product' : 'Edit Product'}
              </h3>
              <button type="button" onClick={() => setEditingProduct(null)} className="text-zinc-400 hover:text-zinc-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-700 block mb-1">Product Title *</label>
              <input
                type="text"
                required
                value={editingProduct.title || ''}
                onChange={(e) => setEditingProduct({ ...editingProduct, title: e.target.value })}
                placeholder="e.g. Yeezy Boost 350 V2 Sneakers"
                className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-zinc-700 block mb-1">Price (₹) *</label>
                <input
                  type="number"
                  step="1"
                  required
                  value={editingProduct.price || 0}
                  onChange={(e) => setEditingProduct({ ...editingProduct, price: parseFloat(e.target.value) })}
                  className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-zinc-700 block mb-1">Stock Count *</label>
                <input
                  type="number"
                  required
                  value={editingProduct.stock || 0}
                  onChange={(e) => setEditingProduct({ ...editingProduct, stock: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-zinc-700 block mb-1">Brand</label>
                <input
                  type="text"
                  value={editingProduct.brand || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, brand: e.target.value })}
                  placeholder="Adidas, Nike, Yeezy, Hawix..."
                  className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-zinc-700 block mb-1">Category Select *</label>
                <select
                  value={editingProduct.category || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600 font-medium"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.name}>{c.name}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Available Shoe Sizes Multiselect */}
            <div className="p-3 bg-zinc-50 border border-zinc-200 rounded-xl space-y-2">
              <label className="text-xs font-bold text-zinc-800 block">Available Shoe Sizes</label>
              <div className="flex flex-wrap gap-2">
                {ALL_SIZES.map((size) => {
                  const isSelected = editingProduct.availableSizes?.includes(size);
                  return (
                    <button
                      key={size}
                      type="button"
                      onClick={() => {
                        const current = editingProduct.availableSizes || [];
                        const updated = isSelected
                          ? current.filter(s => s !== size)
                          : [...current, size];
                        setEditingProduct({ ...editingProduct, availableSizes: updated });
                      }}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                        isSelected 
                          ? 'bg-red-600 text-white shadow-xs' 
                          : 'bg-white border border-zinc-300 text-zinc-700 hover:border-zinc-500'
                      }`}
                    >
                      {size} {isSelected && '✓'}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Main Product Image */}
            <div className="p-3 bg-zinc-50 border border-zinc-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-zinc-800 block">Main Product Photo</label>
                {editingProduct.image && (
                  <button
                    type="button"
                    onClick={() => setEditingProduct({ ...editingProduct, image: '' })}
                    className="text-red-600 hover:text-red-700 text-xs font-bold flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Remove Image
                  </button>
                )}
              </div>
              
              <div className="flex items-center gap-3">
                {editingProduct.image ? (
                  <div className="relative group shrink-0">
                    <img 
                      src={editingProduct.image} 
                      alt="Main Preview" 
                      className="w-16 h-16 object-cover rounded-lg bg-white border border-zinc-200" 
                    />
                    <button
                      type="button"
                      onClick={() => setEditingProduct({ ...editingProduct, image: '' })}
                      className="absolute -top-1.5 -right-1.5 bg-red-600 hover:bg-red-700 text-white rounded-full p-1 shadow-md transition-colors"
                      title="Remove main photo"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <div className="w-16 h-16 rounded-lg border-2 border-dashed border-zinc-300 bg-white flex items-center justify-center text-zinc-400 shrink-0">
                    <ImageIcon className="w-6 h-6" />
                  </div>
                )}

                <div className="flex-1 flex items-center gap-2 flex-wrap">
                  <label className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-bold rounded-lg cursor-pointer inline-flex items-center gap-1.5 shadow-xs">
                    <ImageIcon className="w-3.5 h-3.5" />
                    Upload Main Photo
                    <input 
                      type="file" 
                      accept="image/*" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            if (typeof reader.result === 'string') {
                              setEditingProduct({ ...editingProduct, image: reader.result });
                            }
                          };
                          reader.readAsDataURL(file);
                        }
                      }} 
                      className="hidden" 
                    />
                  </label>

                  {editingProduct.image && (
                    <button
                      type="button"
                      onClick={() => setEditingProduct({ ...editingProduct, image: '' })}
                      className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-600 text-xs font-bold rounded-lg transition-colors flex items-center gap-1 border border-red-200"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Remove Image
                    </button>
                  )}
                </div>
              </div>

              <input
                type="text"
                value={editingProduct.image || ''}
                onChange={(e) => setEditingProduct({ ...editingProduct, image: e.target.value })}
                placeholder="Or paste main image URL (https://...)"
                className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600 bg-white"
              />
            </div>

            {/* Additional Gallery Photos */}
            <div className="p-3 bg-zinc-50 border border-zinc-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-zinc-800 block">Product Gallery Photos (Multiple)</label>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-zinc-400">{(editingProduct.images || []).length} gallery photo(s)</span>
                  {(editingProduct.images || []).length > 0 && (
                    <button
                      type="button"
                      onClick={() => setEditingProduct({ ...editingProduct, images: [] })}
                      className="text-red-600 hover:text-red-700 text-xs font-bold flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Clear Gallery
                    </button>
                  )}
                </div>
              </div>
              
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {(editingProduct.images || []).map((imgUrl, imgIdx) => (
                  <div key={imgIdx} className="relative group shrink-0">
                    <img src={imgUrl} alt={`Gallery ${imgIdx}`} className="w-14 h-14 object-cover rounded-lg border border-zinc-200 bg-white" />
                    <button
                      type="button"
                      onClick={() => {
                        const updated = (editingProduct.images || []).filter((_, i) => i !== imgIdx);
                        setEditingProduct({ ...editingProduct, images: updated });
                      }}
                      className="absolute -top-1.5 -right-1.5 bg-red-600 hover:bg-red-700 text-white rounded-full p-1 shadow-md transition-all"
                      title="Remove image"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}

                <label className="w-14 h-14 rounded-lg border-2 border-dashed border-zinc-300 hover:border-red-600 flex flex-col items-center justify-center cursor-pointer text-zinc-400 hover:text-red-600 shrink-0 bg-white transition-colors">
                  <Plus className="w-4 h-4" />
                  <span className="text-[8px] font-bold">+ Photo</span>
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onloadend = () => {
                          if (typeof reader.result === 'string') {
                            const current = editingProduct.images || [];
                            setEditingProduct({ ...editingProduct, images: [...current, reader.result] });
                          }
                        };
                        reader.readAsDataURL(file);
                      }
                    }} 
                    className="hidden" 
                  />
                </label>
              </div>
            </div>

            {/* COLOR VARIANT IMAGE MAPPER */}
            <div className="p-4 bg-zinc-50 border border-zinc-200 rounded-xl space-y-3">
              <div className="flex items-center gap-2">
                <Palette className="w-4 h-4 text-red-600" />
                <h4 className="text-xs font-extrabold uppercase text-zinc-800 tracking-wider">
                  Color Variant Image Mapping (Dynamic Shoe Swatches)
                </h4>
              </div>
              <p className="text-[11px] text-zinc-500">
                Map specific shoe images to colors (e.g. Green `#10B981` → Green Shoe Image). When a customer taps Green on product page or grid, the shoe image switches immediately!
              </p>

              {/* List mapped variants */}
              {editingProduct.colorVariants && editingProduct.colorVariants.length > 0 && (
                <div className="space-y-3">
                  {editingProduct.colorVariants.map((variant, idx) => {
                    const variantImagesList = variant.images && variant.images.length > 0
                      ? variant.images
                      : (variant.image ? [variant.image] : []);

                    return (
                      <div key={idx} className="bg-white p-3 rounded-lg border border-zinc-200 space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="w-5 h-5 rounded-full border border-zinc-300 shadow-xs" style={{ backgroundColor: variant.colorHex }} />
                            <span className="text-xs font-bold text-zinc-800">{variant.colorName}</span>
                            <span className="text-[10px] text-zinc-400">({variant.colorHex})</span>
                            <span className="text-[10px] font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded">
                              {variantImagesList.length} image{variantImagesList.length > 1 ? 's' : ''}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleRemoveColorVariant(idx)}
                            className="text-red-600 hover:text-red-700 text-xs font-bold p-1 flex items-center gap-1"
                          >
                            <X className="w-4 h-4" /> Remove Swatch
                          </button>
                        </div>

                        {/* Thumbnails list for this color */}
                        <div className="flex items-center gap-2 overflow-x-auto pb-1">
                          {variantImagesList.map((imgUrl, imgIdx) => (
                            <div key={imgIdx} className="relative group shrink-0">
                              <img src={imgUrl} alt={`${variant.colorName} ${imgIdx}`} className="w-12 h-12 object-cover rounded-lg border border-zinc-200" />
                              {variantImagesList.length > 1 && (
                                <button
                                  type="button"
                                  onClick={() => handleRemoveImageFromVariant(idx, imgIdx)}
                                  className="absolute -top-1 -right-1 bg-red-600 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                                  title="Delete photo"
                                >
                                  <X className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                          ))}

                          {/* Add extra image to this color variant */}
                          <label className="w-12 h-12 rounded-lg border-2 border-dashed border-zinc-300 hover:border-red-600 flex flex-col items-center justify-center cursor-pointer text-zinc-400 hover:text-red-600 shrink-0 bg-zinc-50 transition-colors">
                            <Plus className="w-4 h-4" />
                            <span className="text-[8px] font-bold">+ Image</span>
                            <input 
                              type="file" 
                              accept="image/*" 
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  const reader = new FileReader();
                                  reader.onloadend = () => {
                                    if (typeof reader.result === 'string') {
                                      handleAddImageToVariant(idx, reader.result);
                                    }
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }} 
                              className="hidden" 
                            />
                          </label>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Add New Color Variant */}
              <div className="p-3 bg-white rounded-lg border border-zinc-200 space-y-2">
                <span className="text-[11px] font-bold text-zinc-700 block">Add Color & Associated Shoe Image:</span>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={newColorName}
                    onChange={(e) => setNewColorName(e.target.value)}
                    placeholder="Color Name (e.g. Green Glow)"
                    className="px-2.5 py-1.5 text-xs border border-zinc-300 rounded-md outline-none"
                  />
                  <div className="flex items-center gap-1.5">
                    <input
                      type="color"
                      value={newColorHex}
                      onChange={(e) => setNewColorHex(e.target.value)}
                      className="w-8 h-8 rounded border border-zinc-300 cursor-pointer p-0"
                    />
                    <input
                      type="text"
                      value={newColorHex}
                      onChange={(e) => setNewColorHex(e.target.value)}
                      className="flex-1 px-2.5 py-1.5 text-xs border border-zinc-300 rounded-md outline-none font-mono"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={newColorImage}
                    onChange={(e) => setNewColorImage(e.target.value)}
                    placeholder="Specific Image URL for this color variant..."
                    className="flex-1 px-2.5 py-1.5 text-xs border border-zinc-300 rounded-md outline-none"
                  />
                  <label className="px-2.5 py-1.5 bg-zinc-800 text-white text-[11px] font-bold rounded cursor-pointer whitespace-nowrap">
                    Upload
                    <input 
                      type="file" 
                      accept="image/*" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            if (typeof reader.result === 'string') {
                              setNewColorImage(reader.result);
                            }
                          };
                          reader.readAsDataURL(file);
                        }
                      }} 
                      className="hidden" 
                    />
                  </label>
                  <button
                    type="button"
                    onClick={handleAddColorVariant}
                    className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-md whitespace-nowrap"
                  >
                    + Add Swatch
                  </button>
                </div>
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-700 block mb-1">Description</label>
              <textarea
                rows={3}
                value={editingProduct.description || ''}
                onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600 resize-none"
              />
            </div>

            <div className="flex gap-4">
              <label className="flex items-center gap-2 text-xs font-bold text-zinc-700">
                <input
                  type="checkbox"
                  checked={Boolean(editingProduct.isBestSeller)}
                  onChange={(e) => setEditingProduct({ ...editingProduct, isBestSeller: e.target.checked })}
                />
                Best Seller
              </label>
              <label className="flex items-center gap-2 text-xs font-bold text-zinc-700">
                <input
                  type="checkbox"
                  checked={Boolean(editingProduct.isNewArrival)}
                  onChange={(e) => setEditingProduct({ ...editingProduct, isNewArrival: e.target.checked })}
                />
                New Arrival
              </label>
            </div>

            <div className="flex items-center justify-between pt-3 border-t">
              {!isAddingNew && editingProduct.id ? (
                <button
                  type="button"
                  onClick={() => {
                    if (editingProduct.id) {
                      deleteProduct(editingProduct.id);
                      setEditingProduct(null);
                    }
                  }}
                  className="px-3 py-2 bg-red-50 hover:bg-red-100 text-red-600 text-xs font-bold rounded-lg flex items-center gap-1 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Remove Product
                </button>
              ) : <div />}

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="px-4 py-2 bg-zinc-100 text-zinc-700 text-xs font-bold rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-zinc-950 text-white text-xs font-bold rounded-lg hover:bg-red-600 transition-colors"
                >
                  Save Product
                </button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
