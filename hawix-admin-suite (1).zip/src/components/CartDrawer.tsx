import React, { useState } from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, CheckCircle2, Eye, Receipt, Printer, FileText, Truck } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Order } from '../types';

export const CartDrawer: React.FC = () => {
  const { 
    isCartDrawerOpen, 
    setIsCartDrawerOpen, 
    cart, 
    orders,
    removeFromCart, 
    updateCartQuantity, 
    cartTotal, 
    formatPrice,
    placeOrder,
    openTrackOrderWithId 
  } = useApp();

  const [isCheckingOut, setIsCheckingOut] = useState<boolean>(false);
  const [customerName, setCustomerName] = useState<string>('');
  const [customerEmail, setCustomerEmail] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [orderPlacedId, setOrderPlacedId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [showingOrderReceipt, setShowingOrderReceipt] = useState<boolean>(false);

  if (!isCartDrawerOpen) return null;

  // Find confirmed order object from orders list or build current order snapshot
  const confirmedOrder: Order | undefined = orders.find(o => o.id === orderPlacedId);

  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerEmail || !address) return;
    setIsSubmitting(true);
    const orderId = await placeOrder({
      name: customerName,
      email: customerEmail,
      phone: customerPhone,
      address
    });
    setIsSubmitting(false);
    if (orderId) {
      setOrderPlacedId(orderId);
      setIsCheckingOut(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div 
        className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col justify-between"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="p-4 sm:p-6 border-b border-zinc-100 flex items-center justify-between bg-zinc-950 text-white">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-red-600" />
            <h3 className="font-condensed text-xl font-bold uppercase tracking-wider">
              {showingOrderReceipt 
                ? 'Order Receipt & Details' 
                : orderPlacedId 
                ? 'Order Confirmed' 
                : isCheckingOut 
                ? 'Checkout Details' 
                : 'Your Shopping Bag'}
            </h3>
          </div>
          <button 
            onClick={() => {
              setIsCartDrawerOpen(false);
              setOrderPlacedId(null);
              setIsCheckingOut(false);
              setShowingOrderReceipt(false);
            }} 
            className="p-1.5 text-zinc-400 hover:text-white rounded-md transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Drawer Body */}
        <div className="p-4 sm:p-6 flex-1 overflow-y-auto">
          {showingOrderReceipt ? (
            /* FULL ORDER DETAILS VIEW */
            <div className="space-y-4 text-zinc-900 animate-in fade-in duration-200">
              <div className="flex items-center justify-between border-b border-zinc-200 pb-3">
                <div>
                  <span className="text-[10px] uppercase font-bold text-zinc-400 block">Order Reference</span>
                  <h4 className="text-base font-extrabold text-zinc-900">
                    #{orderPlacedId?.slice(-8).toUpperCase()}
                  </h4>
                </div>
                <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold rounded-full">
                  Confirmed Order
                </span>
              </div>

              {/* Customer Info Box */}
              <div className="p-3.5 bg-zinc-50 rounded-xl border border-zinc-200 text-xs space-y-1">
                <span className="font-extrabold uppercase text-zinc-500 text-[10px] block mb-1">
                  Customer & Delivery Info
                </span>
                <p><strong>Name:</strong> {confirmedOrder?.customerName || customerName}</p>
                <p><strong>Email:</strong> {confirmedOrder?.customerEmail || customerEmail}</p>
                {customerPhone && <p><strong>Phone:</strong> {customerPhone}</p>}
                <p><strong>Address:</strong> {confirmedOrder?.address || address}</p>
              </div>

              {/* Ordered Items List */}
              <div className="space-y-2">
                <span className="text-xs font-extrabold uppercase text-zinc-800 block">
                  Purchased Items
                </span>
                {confirmedOrder?.items?.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between p-2.5 bg-zinc-50 rounded-xl border border-zinc-200 text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <img src={item.image} alt={item.title} className="w-10 h-10 object-cover rounded-lg bg-white shrink-0 border" />
                      <div className="min-w-0">
                        <p className="font-bold text-zinc-900 truncate">{item.title}</p>
                        <p className="text-[11px] text-zinc-500">
                          Qty: {item.quantity} {item.selectedSize ? `| Size: ${item.selectedSize}` : ''}
                        </p>
                      </div>
                    </div>
                    <span className="font-extrabold text-zinc-900 shrink-0 ml-2">
                      {formatPrice(item.price * item.quantity)}
                    </span>
                  </div>
                ))}
              </div>

              {/* Summary Total */}
              <div className="p-4 bg-zinc-950 text-white rounded-2xl space-y-2 text-xs">
                <div className="flex justify-between text-zinc-400">
                  <span>Subtotal:</span>
                  <span>{formatPrice(confirmedOrder?.totalAmount || cartTotal)}</span>
                </div>
                <div className="flex justify-between text-zinc-400">
                  <span>Shipping:</span>
                  <span className="text-emerald-400 font-bold">FREE Express Delivery</span>
                </div>
                <div className="flex justify-between text-sm font-black text-white pt-2 border-t border-zinc-800">
                  <span>Total Paid:</span>
                  <span className="text-red-500">{formatPrice(confirmedOrder?.totalAmount || cartTotal)}</span>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowingOrderReceipt(false)}
                  className="flex-1 py-2.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 text-xs font-bold rounded-xl"
                >
                  Back to Summary
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-4 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5"
                >
                  <Printer className="w-4 h-4" /> Print
                </button>
              </div>
            </div>
          ) : orderPlacedId ? (
            /* ORDER CONFIRMED SUMMARY WITH VIEW ORDER OPTION */
            <div className="py-10 text-center space-y-5 animate-in fade-in duration-200">
              <div className="w-20 h-20 bg-emerald-50 border-2 border-emerald-200 rounded-full flex items-center justify-center mx-auto shadow-sm">
                <CheckCircle2 className="w-12 h-12 text-emerald-600" />
              </div>

              <div>
                <h4 className="text-2xl font-black text-zinc-900">Order Confirmed!</h4>
                <p className="text-xs text-zinc-500 max-w-xs mx-auto mt-1">
                  Thank you for shopping with Hawix.in. Your order <strong className="text-zinc-900">#{orderPlacedId.slice(-6).toUpperCase()}</strong> is being processed.
                </p>
              </div>

              {/* Order Box Summary */}
              <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-200 text-xs text-left space-y-2 shadow-xs">
                <div className="flex items-center justify-between border-b border-zinc-200 pb-2">
                  <span className="font-bold text-zinc-800">Customer Details</span>
                  <span className="text-[10px] bg-red-50 text-red-600 font-extrabold px-2 py-0.5 rounded">Hawix Verified</span>
                </div>
                <p className="text-zinc-700"><strong>Name:</strong> {customerName}</p>
                <p className="text-zinc-700"><strong>Email:</strong> {customerEmail}</p>
                <p className="text-zinc-700"><strong>Delivery Address:</strong> {address}</p>
              </div>

              {/* Action Buttons: View Order, Track Order & Continue Shopping */}
              <div className="space-y-2 pt-2">
                <button
                  onClick={() => {
                    setIsCartDrawerOpen(false);
                    if (orderPlacedId) openTrackOrderWithId(orderPlacedId);
                  }}
                  className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-colors shadow-md flex items-center justify-center gap-2"
                >
                  <Truck className="w-4 h-4 text-white" />
                  Track Live Order Status
                </button>

                <button
                  onClick={() => setShowingOrderReceipt(true)}
                  className="w-full py-3 bg-zinc-950 hover:bg-zinc-800 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-2"
                >
                  <Eye className="w-4 h-4 text-red-500" />
                  View Order Details
                </button>

                <button
                  onClick={() => {
                    setOrderPlacedId(null);
                    setIsCartDrawerOpen(false);
                  }}
                  className="w-full py-2.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 font-bold text-xs uppercase rounded-xl transition-colors"
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          ) : isCheckingOut ? (
            <form onSubmit={handleCheckoutSubmit} className="space-y-4">
              <h4 className="text-sm font-bold uppercase text-zinc-800 border-b pb-2">
                Shipping Information
              </h4>
              <div>
                <label className="text-xs font-bold text-zinc-700 block mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Muhammed Ayaan"
                  className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-zinc-700 block mb-1">Email Address *</label>
                <input
                  type="email"
                  required
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  placeholder="ayaan@example.com"
                  className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-zinc-700 block mb-1">Phone Number</label>
                <input
                  type="tel"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="+91 9876543210"
                  className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-zinc-700 block mb-1">Delivery Address *</label>
                <textarea
                  required
                  rows={3}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="House No., Street, City, Pincode"
                  className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg outline-none focus:border-red-600 resize-none"
                />
              </div>

              <div className="pt-4 border-t border-zinc-100">
                <div className="flex justify-between text-sm font-extrabold text-zinc-900 mb-4">
                  <span>Total Amount:</span>
                  <span>{formatPrice(cartTotal)}</span>
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setIsCheckingOut(false)}
                    className="w-1/3 py-2.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 font-bold text-xs rounded-xl"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-2/3 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase rounded-xl transition-colors shadow-md"
                  >
                    {isSubmitting ? 'Placing Order...' : 'Confirm Order'}
                  </button>
                </div>
              </div>
            </form>
          ) : cart.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <ShoppingBag className="w-12 h-12 text-zinc-300 mx-auto" />
              <p className="text-sm font-bold text-zinc-700">Your bag is currently empty</p>
              <p className="text-xs text-zinc-400">Add chunky shoes and retro sneakers to get started!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {cart.map((item, index) => {
                const originalOfferPrice = item.product.originalPrice || Math.round(item.product.price * 1.25);
                const offerSavings = (originalOfferPrice - item.product.price) * item.quantity;

                return (
                  <div 
                    key={`${item.product.id}-${item.selectedColor}-${index}`}
                    className="flex gap-3 p-3 bg-zinc-50 border border-zinc-100 rounded-xl relative group"
                  >
                    <img
                      src={item.product.image}
                      alt={item.product.title}
                      className="w-16 h-16 object-cover rounded-lg bg-white shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-bold text-zinc-900 truncate">
                        {item.product.title}
                      </h4>
                      <div className="flex items-center gap-2 text-[11px] text-zinc-500 mt-0.5">
                        <span className="w-3 h-3 rounded-full border border-zinc-300" style={{ backgroundColor: item.selectedColor }} />
                        
                        {/* Higher offer price next to selling price */}
                        <span className="font-bold text-zinc-900">{formatPrice(item.product.price)}</span>
                        <span className="line-through text-zinc-400 text-[10px]">{formatPrice(originalOfferPrice)}</span>
                      </div>

                      <div className="flex items-center justify-between mt-2">
                        <div className="inline-flex items-center border border-zinc-200 rounded-md bg-white text-xs">
                          <button
                            onClick={() => updateCartQuantity(item.product.id, item.quantity - 1, item.selectedColor)}
                            className="px-2 py-0.5 text-zinc-600 hover:bg-zinc-100 font-bold"
                          >
                            -
                          </button>
                          <span className="px-2.5 py-0.5 font-bold text-zinc-900">{item.quantity}</span>
                          <button
                            onClick={() => updateCartQuantity(item.product.id, item.quantity + 1, item.selectedColor)}
                            className="px-2 py-0.5 text-zinc-600 hover:bg-zinc-100 font-bold"
                          >
                            +
                          </button>
                        </div>

                        <div className="text-right">
                          <span className="text-xs font-extrabold text-zinc-900 block">
                            {formatPrice(item.product.price * item.quantity)}
                          </span>
                          {offerSavings > 0 && (
                            <span className="text-[9px] font-bold text-red-600 bg-red-50 px-1 py-0.2 rounded">
                              Save {formatPrice(offerSavings)}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => removeFromCart(item.product.id, item.selectedColor)}
                      className="p-1 text-zinc-400 hover:text-red-600 transition-colors"
                      title="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Drawer Footer */}
        {!orderPlacedId && !isCheckingOut && cart.length > 0 && (
          <div className="p-4 sm:p-6 border-t border-zinc-100 bg-zinc-50 space-y-3">
            <div className="flex justify-between items-center text-sm font-extrabold text-zinc-900">
              <span>Subtotal:</span>
              <span>{formatPrice(cartTotal)}</span>
            </div>
            <p className="text-[11px] text-zinc-400">Taxes and express shipping calculated at checkout.</p>
            <button
              onClick={() => setIsCheckingOut(true)}
              className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-2 shadow-md shadow-red-600/20"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
