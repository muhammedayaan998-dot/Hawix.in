import React, { useState, useEffect, useRef } from 'react';
import { Search, X, ShoppingBag, Star, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Product } from '../types';

export const SearchBarModal: React.FC = () => {
  const { 
    isSearchModalOpen, 
    setIsSearchModalOpen, 
    products, 
    formatPrice, 
    addToCart, 
    setSelectedProductModal,
    viewProductPage 
  } = useApp();

  const [localQuery, setLocalQuery] = useState<string>('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchModalOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
    } else {
      setLocalQuery('');
    }
  }, [isSearchModalOpen]);

  if (!isSearchModalOpen) return null;

  const filteredProducts = products.filter(p => {
    if (!localQuery.trim()) return false;
    const q = localQuery.toLowerCase();
    return (
      p.title.toLowerCase().includes(q) ||
      p.brand.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q)
    );
  });

  const popularTags = ['Yeezy', 'Samba', 'Fat Laces', 'Jordan 1', 'No-Tie', 'Custom Laces', 'Dunk Low'];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-start justify-center pt-12 sm:pt-20 px-4 animate-in fade-in duration-200">
      <div 
        className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden border border-slate-100 flex flex-col max-h-[85vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Input Bar Top */}
        <div className="p-4 sm:p-6 border-b border-slate-100 flex items-center gap-3 bg-slate-50">
          <Search className="w-6 h-6 text-slate-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={localQuery}
            onChange={(e) => setLocalQuery(e.target.value)}
            placeholder="Search replacement laces, sneaker brands, accessories..."
            className="w-full text-base sm:text-lg font-medium text-slate-900 bg-transparent outline-none placeholder:text-slate-400"
          />
          {localQuery && (
            <button 
              onClick={() => setLocalQuery('')} 
              className="text-xs text-slate-400 hover:text-slate-700 font-bold px-2 py-1 bg-slate-200 rounded-md"
            >
              Clear
            </button>
          )}
          <button
            onClick={() => setIsSearchModalOpen(false)}
            className="p-2 text-slate-400 hover:text-slate-800 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Popular Tag Suggestions */}
        <div className="px-6 py-3 bg-white border-b border-slate-100 flex items-center gap-2 overflow-x-auto text-xs">
          <span className="font-bold text-slate-400 uppercase tracking-wider shrink-0 text-[11px]">Popular:</span>
          {popularTags.map(tag => (
            <button
              key={tag}
              onClick={() => setLocalQuery(tag)}
              className="px-3 py-1 bg-slate-100 hover:bg-lime-400 hover:text-slate-950 text-slate-700 font-semibold rounded-full transition-colors whitespace-nowrap shrink-0 text-xs"
            >
              {tag}
            </button>
          ))}
        </div>

        {/* Results Container */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4">
          {!localQuery.trim() ? (
            <div className="py-12 text-center text-slate-400">
              <Search className="w-12 h-12 mx-auto mb-3 opacity-30 text-slate-400" />
              <p className="text-sm font-medium text-slate-500">Start typing to search products, brands, or lace types...</p>
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="py-12 text-center text-slate-500">
              <p className="text-base font-bold text-slate-800 mb-1">No products found for "{localQuery}"</p>
              <p className="text-xs text-slate-400">Try searching for Yeezy, Samba, Adidas, Jordan, or Custom Laces.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {filteredProducts.map(prod => (
                <div 
                  key={prod.id} 
                  onClick={() => { viewProductPage(prod); setIsSearchModalOpen(false); }}
                  className="flex gap-4 p-3 rounded-xl border border-slate-100 hover:border-slate-300 hover:shadow-md transition-all group bg-white cursor-pointer"
                >
                  <img
                    src={prod.image}
                    alt={prod.title}
                    className="w-20 h-20 object-cover rounded-lg shrink-0 bg-slate-100"
                  />
                  <div className="flex-1 flex flex-col justify-between min-w-0">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">{prod.brand} · {prod.category}</span>
                      <h4 
                        className="text-xs font-bold text-slate-900 truncate group-hover:text-lime-600"
                      >
                        {prod.title}
                      </h4>
                      <div className="flex items-center gap-1.5 mt-1">
                        <span className="text-sm font-extrabold text-slate-900">{formatPrice(prod.price)}</span>
                        {prod.originalPrice && (
                          <span className="text-xs text-slate-400 line-through">{formatPrice(prod.originalPrice)}</span>
                        )}
                        <span className="ml-auto text-[11px] font-semibold text-amber-500 flex items-center gap-0.5">
                          <Star className="w-3 h-3 fill-current" /> {prod.rating}
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2 mt-2">
                      <button
                        onClick={(e) => { e.stopPropagation(); addToCart(prod); setIsSearchModalOpen(false); }}
                        className="flex-1 py-1.5 px-3 bg-slate-900 hover:bg-lime-400 hover:text-slate-950 text-white text-[11px] font-bold rounded-md transition-colors flex items-center justify-center gap-1"
                      >
                        <ShoppingBag className="w-3 h-3" />
                        Add to Cart
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); viewProductPage(prod); setIsSearchModalOpen(false); }}
                        className="p-1.5 border border-slate-200 hover:bg-slate-100 rounded-md text-slate-600"
                        title="View Details"
                      >
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
