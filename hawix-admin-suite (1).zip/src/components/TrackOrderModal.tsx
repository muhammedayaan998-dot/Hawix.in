import React, { useState, useEffect } from 'react';
import { 
  X, 
  Search, 
  Package, 
  Truck, 
  CheckCircle2, 
  Clock, 
  MapPin, 
  User, 
  Mail, 
  Phone, 
  ArrowRight, 
  Copy, 
  Check, 
  MessageSquare,
  AlertCircle,
  RefreshCw,
  ShoppingBag
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Order } from '../types';

export const TrackOrderModal: React.FC = () => {
  const { 
    isTrackOrderOpen, 
    setIsTrackOrderOpen, 
    orders, 
    trackOrderQuery, 
    setTrackOrderQuery,
    formatPrice,
    setIsCustomLaceModalOpen
  } = useApp();

  const [inputQuery, setInputQuery] = useState<string>('');
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<boolean>(false);

  // Sync external search query when opened
  useEffect(() => {
    if (trackOrderQuery) {
      setInputQuery(trackOrderQuery);
      setSelectedOrderId(trackOrderQuery);
    }
  }, [trackOrderQuery, isTrackOrderOpen]);

  if (!isTrackOrderOpen) return null;

  // Filter orders matching input query (ID or Email)
  const matchingOrders = orders.filter(o => {
    if (!inputQuery.trim()) return false;
    const q = inputQuery.trim().toLowerCase();
    const cleanId = q.replace('#', '');
    return (
      o.id.toLowerCase().includes(cleanId) ||
      o.customerEmail.toLowerCase().includes(q) ||
      o.customerPhone.includes(q) ||
      o.customerName.toLowerCase().includes(q)
    );
  });

  // Selected active order object
  const activeOrder: Order | undefined = orders.find(o => o.id === selectedOrderId) || matchingOrders[0];

  const handleCopyId = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  // Helper for timeline steps status
  const getStepStatus = (orderStatus: Order['status'], stepIndex: number) => {
    // Steps: 0: Pending/Confirmed, 1: Processing, 2: Shipped, 3: Delivered
    const statusMap: Record<Order['status'], number> = {
      'pending': 0,
      'processing': 1,
      'shipped': 2,
      'delivered': 3,
      'cancelled': -1
    };

    const currentLevel = statusMap[orderStatus] ?? 0;

    if (orderStatus === 'cancelled') {
      return 'cancelled';
    }

    if (currentLevel > stepIndex) return 'completed';
    if (currentLevel === stepIndex) return 'current';
    return 'upcoming';
  };

  const calculateEstimatedDelivery = (createdAtStr: string) => {
    const created = new Date(createdAtStr);
    if (isNaN(created.getTime())) return '2-4 Business Days';
    const deliveryMin = new Date(created);
    deliveryMin.setDate(deliveryMin.getDate() + 2);
    const deliveryMax = new Date(created);
    deliveryMax.setDate(deliveryMax.getDate() + 4);

    return `${deliveryMin.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })} - ${deliveryMax.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div 
        className="bg-white w-full max-w-4xl h-[90vh] rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-zinc-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-6 bg-zinc-950 text-white flex items-center justify-between border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center font-black shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-condensed text-xl sm:text-2xl font-black uppercase tracking-wide flex items-center gap-2">
                TRACK YOUR ORDER <span className="text-red-600 text-xs font-bold px-2 py-0.5 bg-zinc-900 rounded-md">Live Firestore Data</span>
              </h2>
              <p className="text-xs text-zinc-400 font-medium">Real-time order tracking & delivery status updates</p>
            </div>
          </div>

          <button
            onClick={() => setIsTrackOrderOpen(false)}
            className="p-2 text-zinc-400 hover:text-white rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Search Bar Section */}
        <div className="p-4 sm:p-6 bg-zinc-50 border-b border-zinc-200 space-y-3">
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              if (matchingOrders.length > 0) {
                setSelectedOrderId(matchingOrders[0].id);
              }
            }}
            className="flex items-center gap-2"
          >
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
              <input
                type="text"
                value={inputQuery}
                onChange={(e) => {
                  setInputQuery(e.target.value);
                  setTrackOrderQuery(e.target.value);
                }}
                placeholder="Enter Order ID (e.g. #3A9B4F or full ID) or Email address..."
                className="w-full pl-10 pr-4 py-3 bg-white border border-zinc-300 rounded-xl text-xs sm:text-sm font-semibold outline-none focus:border-red-600 focus:ring-2 focus:ring-red-600/20 shadow-xs"
              />
              {inputQuery && (
                <button
                  type="button"
                  onClick={() => { setInputQuery(''); setTrackOrderQuery(''); setSelectedOrderId(null); }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-700 text-xs font-bold"
                >
                  Clear
                </button>
              )}
            </div>

            <button
              type="submit"
              className="px-5 py-3 bg-zinc-950 hover:bg-zinc-800 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-colors shadow-md shrink-0 flex items-center gap-1.5"
            >
              <Search className="w-4 h-4" />
              <span>Track</span>
            </button>
          </form>

          {/* Quick preset matching orders pills if email matched multiple */}
          {matchingOrders.length > 1 && (
            <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-1">
              <span className="text-[11px] font-bold text-zinc-500 shrink-0">Matching Orders ({matchingOrders.length}):</span>
              {matchingOrders.map(o => (
                <button
                  key={o.id}
                  onClick={() => setSelectedOrderId(o.id)}
                  className={`px-3 py-1 text-xs font-bold rounded-lg border transition-all shrink-0 ${
                    activeOrder?.id === o.id
                      ? 'bg-red-600 text-white border-red-600 shadow-xs'
                      : 'bg-white text-zinc-700 border-zinc-300 hover:border-zinc-500'
                  }`}
                >
                  #{o.id.slice(-6).toUpperCase()} ({new Date(o.createdAt).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })})
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-white space-y-6">
          
          {!activeOrder ? (
            <div className="py-16 text-center space-y-4 max-w-md mx-auto">
              <div className="w-16 h-16 rounded-full bg-zinc-100 flex items-center justify-center mx-auto text-zinc-400">
                <Package className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-zinc-900">
                  {inputQuery ? 'No Order Found' : 'Search Your Hawix Order'}
                </h3>
                <p className="text-xs text-zinc-500 mt-1">
                  {inputQuery 
                    ? `No matching order found for "${inputQuery}". Please double-check your Order ID or Email.` 
                    : 'Enter your Hawix Order ID or the email address used during checkout to view real-time status.'}
                </p>
              </div>

              {orders.length > 0 && !inputQuery && (
                <div className="pt-4 border-t border-zinc-100 text-left">
                  <span className="text-xs font-bold text-zinc-700 block mb-2">Recent Store Orders (Tap to Track):</span>
                  <div className="space-y-2">
                    {orders.slice(0, 3).map(o => (
                      <div 
                        key={o.id}
                        onClick={() => {
                          setInputQuery(o.id);
                          setSelectedOrderId(o.id);
                        }}
                        className="p-3 bg-zinc-50 hover:bg-zinc-100 rounded-xl border border-zinc-200 cursor-pointer transition-colors flex items-center justify-between"
                      >
                        <div>
                          <p className="text-xs font-bold text-zinc-900">Order #{o.id.slice(-8).toUpperCase()}</p>
                          <p className="text-[11px] text-zinc-500">{o.customerName} · {o.items?.length || 0} item(s)</p>
                        </div>
                        <span className="text-xs font-extrabold text-red-600 bg-red-50 px-2.5 py-1 rounded-md uppercase">
                          {o.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-6 animate-in fade-in duration-200">
              
              {/* Order Header Info Card */}
              <div className="bg-zinc-950 text-white p-5 sm:p-6 rounded-2xl shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs uppercase font-bold text-zinc-400">Order Reference ID</span>
                    <span className="text-xs text-zinc-500">·</span>
                    <span className="text-xs text-zinc-400 font-medium">
                      Placed on {new Date(activeOrder.createdAt).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-3 mt-1">
                    <h3 className="text-xl sm:text-2xl font-black font-mono tracking-tight text-white">
                      #{activeOrder.id.slice(-8).toUpperCase()}
                    </h3>
                    <button
                      onClick={() => handleCopyId(activeOrder.id)}
                      className="p-1.5 bg-zinc-800 hover:bg-zinc-700 rounded-md text-xs font-bold flex items-center gap-1 text-zinc-300 transition-colors"
                      title="Copy Full ID"
                    >
                      {copiedId ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span className="text-[10px]">{copiedId ? 'Copied' : 'Copy ID'}</span>
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] uppercase font-bold text-zinc-400 block">Total Amount</span>
                    <span className="text-lg font-black text-white">{formatPrice(activeOrder.totalAmount)}</span>
                  </div>

                  <div className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-sm ${
                    activeOrder.status === 'delivered' 
                      ? 'bg-emerald-600 text-white' 
                      : activeOrder.status === 'shipped'
                      ? 'bg-blue-600 text-white animate-pulse'
                      : activeOrder.status === 'processing'
                      ? 'bg-amber-500 text-zinc-950 font-bold'
                      : activeOrder.status === 'cancelled'
                      ? 'bg-red-600 text-white'
                      : 'bg-zinc-800 text-white border border-zinc-700'
                  }`}>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: '4s' }} />
                    <span>{activeOrder.status}</span>
                  </div>
                </div>
              </div>

              {/* 4-Step Visual Tracking Progress Bar */}
              <div className="bg-zinc-50 p-6 rounded-2xl border border-zinc-200 space-y-6">
                <div className="flex items-center justify-between border-b border-zinc-200 pb-3">
                  <h4 className="text-xs font-extrabold uppercase tracking-wider text-zinc-800 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-red-600" /> Live Delivery Timeline
                  </h4>
                  <span className="text-xs font-bold text-zinc-600">
                    Estimated Delivery: <strong className="text-zinc-900">{calculateEstimatedDelivery(activeOrder.createdAt)}</strong>
                  </span>
                </div>

                {activeOrder.status === 'cancelled' ? (
                  <div className="p-4 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs font-bold flex items-center gap-2">
                    <AlertCircle className="w-5 h-5 shrink-0" />
                    <span>This order was cancelled. If you have questions regarding a refund, please contact Hawix Support.</span>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 relative">
                    
                    {/* Step 1: Placed */}
                    {(() => {
                      const status = getStepStatus(activeOrder.status, 0);
                      return (
                        <div className={`p-4 rounded-xl border flex flex-col justify-between transition-all ${
                          status === 'completed' || status === 'current' 
                            ? 'bg-white border-red-600 shadow-xs' 
                            : 'bg-zinc-100 border-zinc-200 opacity-60'
                        }`}>
                          <div className="flex items-center justify-between mb-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                              status === 'completed' 
                                ? 'bg-red-600 text-white' 
                                : status === 'current'
                                ? 'bg-zinc-950 text-white ring-4 ring-red-600/20'
                                : 'bg-zinc-200 text-zinc-600'
                            }`}>
                              {status === 'completed' ? <Check className="w-4 h-4" /> : '1'}
                            </div>
                            <span className="text-[10px] font-extrabold uppercase text-zinc-400">Step 1</span>
                          </div>
                          <div>
                            <h5 className="text-xs font-extrabold text-zinc-900">Order Placed</h5>
                            <p className="text-[11px] text-zinc-500 mt-0.5">Order logged in Firestore</p>
                          </div>
                        </div>
                      );
                    })()}

                    {/* Step 2: Processing */}
                    {(() => {
                      const status = getStepStatus(activeOrder.status, 1);
                      return (
                        <div className={`p-4 rounded-xl border flex flex-col justify-between transition-all ${
                          status === 'completed' || status === 'current' 
                            ? 'bg-white border-red-600 shadow-xs' 
                            : 'bg-zinc-100 border-zinc-200 opacity-60'
                        }`}>
                          <div className="flex items-center justify-between mb-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                              status === 'completed' 
                                ? 'bg-red-600 text-white' 
                                : status === 'current'
                                ? 'bg-zinc-950 text-white ring-4 ring-red-600/20'
                                : 'bg-zinc-200 text-zinc-600'
                            }`}>
                              {status === 'completed' ? <Check className="w-4 h-4" /> : '2'}
                            </div>
                            <span className="text-[10px] font-extrabold uppercase text-zinc-400">Step 2</span>
                          </div>
                          <div>
                            <h5 className="text-xs font-extrabold text-zinc-900">Quality Inspection</h5>
                            <p className="text-[11px] text-zinc-500 mt-0.5">Packed at Hawix Hub</p>
                          </div>
                        </div>
                      );
                    })()}

                    {/* Step 3: Shipped */}
                    {(() => {
                      const status = getStepStatus(activeOrder.status, 2);
                      return (
                        <div className={`p-4 rounded-xl border flex flex-col justify-between transition-all ${
                          status === 'completed' || status === 'current' 
                            ? 'bg-white border-red-600 shadow-xs' 
                            : 'bg-zinc-100 border-zinc-200 opacity-60'
                        }`}>
                          <div className="flex items-center justify-between mb-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                              status === 'completed' 
                                ? 'bg-red-600 text-white' 
                                : status === 'current'
                                ? 'bg-zinc-950 text-white ring-4 ring-red-600/20'
                                : 'bg-zinc-200 text-zinc-600'
                            }`}>
                              {status === 'completed' ? <Check className="w-4 h-4" /> : '3'}
                            </div>
                            <span className="text-[10px] font-extrabold uppercase text-zinc-400">Step 3</span>
                          </div>
                          <div>
                            <h5 className="text-xs font-extrabold text-zinc-900">Out for Express Delivery</h5>
                            <p className="text-[11px] text-zinc-500 mt-0.5">In transit with carrier</p>
                          </div>
                        </div>
                      );
                    })()}

                    {/* Step 4: Delivered */}
                    {(() => {
                      const status = getStepStatus(activeOrder.status, 3);
                      return (
                        <div className={`p-4 rounded-xl border flex flex-col justify-between transition-all ${
                          status === 'completed' 
                            ? 'bg-emerald-50 border-emerald-500 shadow-xs' 
                            : status === 'current'
                            ? 'bg-white border-red-600 shadow-xs'
                            : 'bg-zinc-100 border-zinc-200 opacity-60'
                        }`}>
                          <div className="flex items-center justify-between mb-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                              status === 'completed' 
                                ? 'bg-emerald-600 text-white' 
                                : 'bg-zinc-200 text-zinc-600'
                            }`}>
                              {status === 'completed' ? <Check className="w-4 h-4" /> : '4'}
                            </div>
                            <span className="text-[10px] font-extrabold uppercase text-zinc-400">Step 4</span>
                          </div>
                          <div>
                            <h5 className="text-xs font-extrabold text-zinc-900">Delivered</h5>
                            <p className="text-[11px] text-zinc-500 mt-0.5">Handed over to recipient</p>
                          </div>
                        </div>
                      );
                    })()}

                  </div>
                )}
              </div>

              {/* Grid: Customer Details & Items Purchased */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                
                {/* Column 1: Items Purchased (7 cols) */}
                <div className="md:col-span-7 bg-white p-5 rounded-2xl border border-zinc-200 space-y-4">
                  <h4 className="text-xs font-extrabold uppercase tracking-wider text-zinc-800 flex items-center gap-2 border-b border-zinc-100 pb-3">
                    <ShoppingBag className="w-4 h-4 text-red-600" /> Order Items ({activeOrder.items?.length || 0})
                  </h4>

                  <div className="space-y-3">
                    {activeOrder.items?.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-3 p-3 bg-zinc-50 rounded-xl border border-zinc-100">
                        <img 
                          src={item.image || 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800'} 
                          alt={item.title} 
                          className="w-14 h-14 object-cover rounded-lg bg-white border border-zinc-200 shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <h5 className="text-xs font-extrabold text-zinc-900 truncate">{item.title}</h5>
                          <div className="flex items-center gap-2 text-[11px] text-zinc-500 mt-0.5 flex-wrap">
                            {item.selectedSize && <span className="bg-white px-1.5 py-0.5 rounded border text-zinc-800 font-bold">{item.selectedSize}</span>}
                            {item.selectedColor && (
                              <span className="flex items-center gap-1">
                                Color: <span className="w-3 h-3 rounded-full border inline-block" style={{ backgroundColor: item.selectedColor }} />
                              </span>
                            )}
                            <span>Qty: <strong>{item.quantity}</strong></span>
                          </div>
                        </div>
                        <span className="text-xs font-black text-zinc-900 shrink-0">{formatPrice(item.price * item.quantity)}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-3 border-t border-zinc-100 flex items-center justify-between text-xs font-extrabold text-zinc-900">
                    <span>Order Total (Inclusive Taxes):</span>
                    <span className="text-base text-red-600 font-black">{formatPrice(activeOrder.totalAmount)}</span>
                  </div>
                </div>

                {/* Column 2: Shipping Info (5 cols) */}
                <div className="md:col-span-5 bg-zinc-50 p-5 rounded-2xl border border-zinc-200 space-y-4">
                  <h4 className="text-xs font-extrabold uppercase tracking-wider text-zinc-800 flex items-center gap-2 border-b border-zinc-200 pb-3">
                    <MapPin className="w-4 h-4 text-red-600" /> Delivery Address & Contact
                  </h4>

                  <div className="space-y-3 text-xs text-zinc-700">
                    <div className="flex items-start gap-2.5">
                      <User className="w-4 h-4 text-zinc-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="text-[10px] font-bold text-zinc-400 block uppercase">Recipient Name</span>
                        <strong className="text-zinc-900 font-bold">{activeOrder.customerName}</strong>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <Mail className="w-4 h-4 text-zinc-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="text-[10px] font-bold text-zinc-400 block uppercase">Customer Email</span>
                        <span className="font-medium text-zinc-800">{activeOrder.customerEmail}</span>
                      </div>
                    </div>

                    {activeOrder.customerPhone && (
                      <div className="flex items-start gap-2.5">
                        <Phone className="w-4 h-4 text-zinc-400 shrink-0 mt-0.5" />
                        <div>
                          <span className="text-[10px] font-bold text-zinc-400 block uppercase">Contact Phone</span>
                          <span className="font-medium text-zinc-800">{activeOrder.customerPhone}</span>
                        </div>
                      </div>
                    )}

                    <div className="flex items-start gap-2.5 pt-2 border-t border-zinc-200">
                      <MapPin className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="text-[10px] font-bold text-zinc-400 block uppercase">Shipping Address</span>
                        <p className="font-bold text-zinc-900 leading-snug">{activeOrder.address}</p>
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-zinc-200 space-y-2">
                    <button
                      onClick={() => {
                        setIsTrackOrderOpen(false);
                        setIsCustomLaceModalOpen(true);
                      }}
                      className="w-full py-2.5 bg-white hover:bg-zinc-100 border border-zinc-300 text-zinc-800 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5"
                    >
                      <MessageSquare className="w-4 h-4 text-red-600" />
                      Need Help with Order?
                    </button>
                  </div>

                </div>

              </div>

            </div>
          )}

        </div>
      </div>
    </div>
  );
};
