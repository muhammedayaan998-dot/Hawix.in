import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  collection, 
  doc, 
  onSnapshot, 
  setDoc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs,
  serverTimestamp 
} from 'firebase/firestore';
import { onAuthStateChanged, signInWithEmailAndPassword, signOut, User } from 'firebase/auth';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { Product, SiteConfig, Order, Enquiry, CartItem, CategoryItem } from '../types';
import { INITIAL_PRODUCTS, INITIAL_SITE_CONFIG, INITIAL_CATEGORIES } from '../data/initialData';

export const ADMIN_EMAIL = 'muhammedayaan119@gmail.com';
export const ADMIN_PASSWORD = 'Ayaan,Aslam,Hawix,1000';

interface AppContextType {
  // Products, Categories & Config
  products: Product[];
  categories: CategoryItem[];
  siteConfig: SiteConfig;
  loadingProducts: boolean;
  
  // Auth & Admin
  user: User | null;
  isAdmin: boolean;
  adminLoginError: string | null;
  loginAsAdmin: (email: string, pass: string) => Promise<boolean>;
  logout: () => Promise<void>;
  
  // Currency
  currency: 'USD' | 'INR';
  setCurrency: (c: 'USD' | 'INR') => void;
  formatPrice: (amountInUSD: number) => string;
  
  // Search & Filters
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  selectedBrand: string;
  setSelectedBrand: (b: string) => void;
  
  // Cart
  cart: CartItem[];
  addToCart: (product: Product, selectedColor?: string, quantity?: number) => void;
  removeFromCart: (productId: string, selectedColor?: string) => void;
  updateCartQuantity: (productId: string, quantity: number, selectedColor?: string) => void;
  clearCart: () => void;
  cartTotal: number;
  cartCount: number;
  
  // Orders & Enquiries
  orders: Order[];
  enquiries: Enquiry[];
  placeOrder: (customerInfo: { name: string; email: string; phone: string; address: string }) => Promise<string>;
  submitEnquiry: (enquiry: { name: string; email: string; subject: string; message: string }) => Promise<void>;
  
  // Admin Operations
  addProduct: (product: Omit<Product, 'id'>) => Promise<void>;
  updateProduct: (id: string, product: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  addCategory: (category: Omit<CategoryItem, 'id'>) => Promise<void>;
  updateCategory: (id: string, category: Partial<CategoryItem>) => Promise<void>;
  deleteCategory: (id: string) => Promise<void>;
  updateSiteConfig: (config: Partial<SiteConfig>) => Promise<void>;
  updateOrderStatus: (orderId: string, status: Order['status']) => Promise<void>;
  
  // UI Modals
  isLoginModalOpen: boolean;
  setIsLoginModalOpen: (open: boolean) => void;
  isSearchModalOpen: boolean;
  setIsSearchModalOpen: (open: boolean) => void;
  isCartDrawerOpen: boolean;
  setIsCartDrawerOpen: (open: boolean) => void;
  isAdminPortalOpen: boolean;
  setIsAdminPortalOpen: (open: boolean) => void;
  isCustomLaceModalOpen: boolean;
  setIsCustomLaceModalOpen: (open: boolean) => void;
  selectedProductModal: Product | null;
  setSelectedProductModal: (prod: Product | null) => void;
  selectedProductPage: Product | null;
  setSelectedProductPage: (prod: Product | null) => void;
  viewProductPage: (prod: Product) => void;
  
  // Track Order Modal
  isTrackOrderOpen: boolean;
  setIsTrackOrderOpen: (open: boolean) => void;
  trackOrderQuery: string;
  setTrackOrderQuery: (q: string) => void;
  openTrackOrderWithId: (orderId: string) => void;
  
  // Quick status notification banner
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [categories, setCategories] = useState<CategoryItem[]>(INITIAL_CATEGORIES);
  const [siteConfig, setSiteConfig] = useState<SiteConfig>(INITIAL_SITE_CONFIG);
  const [loadingProducts, setLoadingProducts] = useState<boolean>(true);
  
  const [user, setUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [adminLoginError, setAdminLoginError] = useState<string | null>(null);
  
  const [currency, setCurrency] = useState<'USD' | 'INR'>('INR');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedBrand, setSelectedBrand] = useState<string>('All');
  
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  
  // Modal states
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState<boolean>(false);
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState<boolean>(false);
  const [isAdminPortalOpen, setIsAdminPortalOpen] = useState<boolean>(false);
  const [isCustomLaceModalOpen, setIsCustomLaceModalOpen] = useState<boolean>(false);
  const [selectedProductModal, setSelectedProductModal] = useState<Product | null>(null);
  const [selectedProductPage, setSelectedProductPage] = useState<Product | null>(null);
  
  // Track Order Modal State
  const [isTrackOrderOpen, setIsTrackOrderOpen] = useState<boolean>(false);
  const [trackOrderQuery, setTrackOrderQuery] = useState<string>('');

  const openTrackOrderWithId = (orderId: string) => {
    setTrackOrderQuery(orderId);
    setIsTrackOrderOpen(true);
  };
  
  const viewProductPage = (prod: Product) => {
    setSelectedProductPage(prod);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Auth Listener & Secret Admin Persistence
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser && currentUser.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
        setIsAdmin(true);
      }
    });

    // Also check local storage for custom secret admin session override
    const storedAdminSession = localStorage.getItem('hawix_admin_session');
    if (storedAdminSession === 'true') {
      setIsAdmin(true);
    }

    return () => unsubscribe();
  }, []);

  // Sync Products from Firestore
  useEffect(() => {
    const unsubProducts = onSnapshot(collection(db, 'products'), async (snapshot) => {
      if (snapshot.empty) {
        // Seed initial products if DB is fresh
        try {
          for (const prod of INITIAL_PRODUCTS) {
            await setDoc(doc(db, 'products', prod.id), {
              ...prod,
              updatedAt: new Date().toISOString()
            });
          }
        } catch (err) {
          console.warn('Auto-seeding initial products notice:', err);
        }
      } else {
        const fetchedProducts: Product[] = snapshot.docs.map(docSnap => ({
          id: docSnap.id,
          ...docSnap.data()
        } as Product));
        setProducts(fetchedProducts);
      }
      setLoadingProducts(false);
    }, (error) => {
      console.warn('Firestore Products sync notice:', error);
      setProducts(INITIAL_PRODUCTS);
      setLoadingProducts(false);
    });

    // Sync Categories from Firestore
    const unsubCategories = onSnapshot(collection(db, 'categories'), async (snapshot) => {
      if (snapshot.empty) {
        try {
          for (const cat of INITIAL_CATEGORIES) {
            await setDoc(doc(db, 'categories', cat.id), cat);
          }
        } catch (err) {
          console.warn('Auto-seeding initial categories notice:', err);
        }
      } else {
        const fetchedCategories: CategoryItem[] = snapshot.docs.map(docSnap => ({
          id: docSnap.id,
          ...docSnap.data()
        } as CategoryItem));
        setCategories(fetchedCategories);
      }
    }, (error) => {
      console.warn('Firestore Categories sync notice:', error);
      setCategories(INITIAL_CATEGORIES);
    });

    // Sync Site Config from Firestore
    const unsubConfig = onSnapshot(doc(db, 'siteConfig', 'main'), async (docSnap) => {
      if (!docSnap.exists()) {
        try {
          await setDoc(doc(db, 'siteConfig', 'main'), INITIAL_SITE_CONFIG);
        } catch (err) {
          console.warn('Auto-seeding siteConfig notice:', err);
        }
      } else {
        setSiteConfig({
          ...INITIAL_SITE_CONFIG,
          ...docSnap.data()
        } as SiteConfig);
      }
    }, (error) => {
      console.warn('Firestore SiteConfig sync notice:', error);
      setSiteConfig(INITIAL_SITE_CONFIG);
    });

    // Sync Orders for Admin
    const unsubOrders = onSnapshot(collection(db, 'orders'), (snapshot) => {
      const fetchedOrders: Order[] = snapshot.docs.map(docSnap => ({
        id: docSnap.id,
        ...docSnap.data()
      } as Order));
      setOrders(fetchedOrders);
    }, (error) => {
      console.warn('Orders sync notice:', error);
    });

    // Sync Enquiries for Admin
    const unsubEnquiries = onSnapshot(collection(db, 'enquiries'), (snapshot) => {
      const fetchedEnquiries: Enquiry[] = snapshot.docs.map(docSnap => ({
        id: docSnap.id,
        ...docSnap.data()
      } as Enquiry));
      setEnquiries(fetchedEnquiries);
    }, (error) => {
      console.warn('Enquiries sync notice:', error);
    });

    return () => {
      unsubProducts();
      unsubCategories();
      unsubConfig();
      unsubOrders();
      unsubEnquiries();
    };
  }, []);

  // Admin Login implementation with exact user credentials
  const loginAsAdmin = async (email: string, pass: string): Promise<boolean> => {
    setAdminLoginError(null);
    const cleanEmail = email.trim().toLowerCase();
    
    const cleanPass = pass.trim().toLowerCase();
    const isValidAdminPass = (
      cleanPass === 'ayaan,aslam,1000' || 
      cleanPass === 'ayaan,aslam,hawix,1000' || 
      pass === ADMIN_PASSWORD
    );
    
    // Check secret credentials requested by user
    if (cleanEmail === ADMIN_EMAIL.toLowerCase() && isValidAdminPass) {
      setIsAdmin(true);
      localStorage.setItem('hawix_admin_session', 'true');
      showToast('⚡ Welcome Admin! Authentication Successful.');
      setIsLoginModalOpen(false);
      setIsAdminPortalOpen(true);
      return true;
    } else {
      // Try Firebase Auth standard sign in fallback
      try {
        const userCredential = await signInWithEmailAndPassword(auth, cleanEmail, pass);
        if (userCredential.user.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
          setIsAdmin(true);
          localStorage.setItem('hawix_admin_session', 'true');
          showToast('⚡ Welcome Admin!');
          setIsLoginModalOpen(false);
          setIsAdminPortalOpen(true);
          return true;
        } else {
          showToast('Logged in as Customer.');
          setIsLoginModalOpen(false);
          return true;
        }
      } catch (err: any) {
        setAdminLoginError('Invalid credentials. Please verify your Email and Secret Admin Password.');
        return false;
      }
    }
  };

  const logout = async () => {
    await signOut(auth);
    setIsAdmin(false);
    localStorage.removeItem('hawix_admin_session');
    showToast('Signed out successfully.');
  };

  // Format price in Indian Rupees (₹)
  const formatPrice = (amount: number): string => {
    const val = amount < 100 ? Math.round(amount * 75) : amount;
    return `₹${val.toLocaleString('en-IN')}`;
  };

  // Cart Functions
  const addToCart = (product: Product, selectedColor?: string, quantity: number = 1) => {
    const color = selectedColor || (product.colors && product.colors.length > 0 ? product.colors[0] : '#000000');
    setCart(prevCart => {
      const existingIndex = prevCart.findIndex(
        item => item.product.id === product.id && item.selectedColor === color
      );
      if (existingIndex > -1) {
        const updated = [...prevCart];
        updated[existingIndex].quantity += quantity;
        return updated;
      }
      return [...prevCart, { product, selectedColor: color, quantity }];
    });
    showToast(`Added "${product.title}" to cart!`);
    setIsCartDrawerOpen(true);
  };

  const removeFromCart = (productId: string, selectedColor?: string) => {
    setCart(prevCart => prevCart.filter(
      item => !(item.product.id === productId && (selectedColor ? item.selectedColor === selectedColor : true))
    ));
    showToast('Item removed from cart.');
  };

  const updateCartQuantity = (productId: string, quantity: number, selectedColor?: string) => {
    if (quantity <= 0) {
      removeFromCart(productId, selectedColor);
      return;
    }
    setCart(prevCart => prevCart.map(item => {
      if (item.product.id === productId && (selectedColor ? item.selectedColor === selectedColor : true)) {
        return { ...item, quantity };
      }
      return item;
    }));
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Orders & Enquiries
  const placeOrder = async (customerInfo: { name: string; email: string; phone: string; address: string }): Promise<string> => {
    const orderData: Omit<Order, 'id'> = {
      customerName: customerInfo.name,
      customerEmail: customerInfo.email,
      customerPhone: customerInfo.phone,
      address: customerInfo.address,
      items: cart.map(item => ({
        productId: item.product.id,
        title: item.product.title,
        price: item.product.price,
        quantity: item.quantity,
        selectedColor: item.selectedColor,
        image: item.product.image
      })),
      totalAmount: cartTotal,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    try {
      const docRef = await addDoc(collection(db, 'orders'), orderData);
      clearCart();
      showToast('🎉 Order placed successfully! Thank you for shopping with Hawix.in');
      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'orders');
      return '';
    }
  };

  const submitEnquiry = async (enquiry: { name: string; email: string; subject: string; message: string }) => {
    try {
      await addDoc(collection(db, 'enquiries'), {
        ...enquiry,
        createdAt: new Date().toISOString()
      });
      showToast('Thank you! Your inquiry has been received by Hawix.in team.');
      setIsCustomLaceModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'enquiries');
    }
  };

  // Admin CRUD for Products
  const addProduct = async (productData: Omit<Product, 'id'>) => {
    const newId = `prod-${Date.now()}`;
    const newProduct: Product = {
      ...productData,
      id: newId,
      updatedAt: new Date().toISOString()
    };
    try {
      await setDoc(doc(db, 'products', newId), newProduct);
      showToast('Product added successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `products/${newId}`);
    }
  };

  const updateProduct = async (id: string, productData: Partial<Product>) => {
    try {
      await updateDoc(doc(db, 'products', id), {
        ...productData,
        updatedAt: new Date().toISOString()
      });
      showToast('Product updated successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `products/${id}`);
    }
  };

  const deleteProduct = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'products', id));
      showToast('Product removed.');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `products/${id}`);
    }
  };

  // Admin CRUD for Categories
  const addCategory = async (categoryData: Omit<CategoryItem, 'id'>) => {
    const newId = `cat-${Date.now()}`;
    const newCat: CategoryItem = {
      ...categoryData,
      id: newId
    };
    try {
      await setDoc(doc(db, 'categories', newId), newCat);
      showToast('Category created successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `categories/${newId}`);
    }
  };

  const updateCategory = async (id: string, categoryData: Partial<CategoryItem>) => {
    try {
      await updateDoc(doc(db, 'categories', id), categoryData);
      showToast('Category updated successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `categories/${id}`);
    }
  };

  const deleteCategory = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'categories', id));
      showToast('Category removed.');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `categories/${id}`);
    }
  };

  // Admin CRUD for Site Config
  const updateSiteConfig = async (configData: Partial<SiteConfig>) => {
    const updated = {
      ...siteConfig,
      ...configData,
      updatedAt: new Date().toISOString()
    };
    try {
      await setDoc(doc(db, 'siteConfig', 'main'), updated);
      showToast('Website customized & updated successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'siteConfig/main');
    }
  };

  const updateOrderStatus = async (orderId: string, status: Order['status']) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), { status });
      showToast(`Order status updated to ${status}`);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `orders/${orderId}`);
    }
  };

  return (
    <AppContext.Provider value={{
      products,
      categories,
      siteConfig,
      loadingProducts,
      user,
      isAdmin,
      adminLoginError,
      loginAsAdmin,
      logout,
      currency,
      setCurrency,
      formatPrice,
      searchQuery,
      setSearchQuery,
      selectedCategory,
      setSelectedCategory,
      selectedBrand,
      setSelectedBrand,
      cart,
      addToCart,
      removeFromCart,
      updateCartQuantity,
      clearCart,
      cartTotal,
      cartCount,
      orders,
      enquiries,
      placeOrder,
      submitEnquiry,
      addProduct,
      updateProduct,
      deleteProduct,
      addCategory,
      updateCategory,
      deleteCategory,
      updateSiteConfig,
      updateOrderStatus,
      isLoginModalOpen,
      setIsLoginModalOpen,
      isSearchModalOpen,
      setIsSearchModalOpen,
      isCartDrawerOpen,
      setIsCartDrawerOpen,
      isAdminPortalOpen,
      setIsAdminPortalOpen,
      isCustomLaceModalOpen,
      setIsCustomLaceModalOpen,
      selectedProductModal,
      setSelectedProductModal,
      selectedProductPage,
      setSelectedProductPage,
      viewProductPage,
      isTrackOrderOpen,
      setIsTrackOrderOpen,
      trackOrderQuery,
      setTrackOrderQuery,
      openTrackOrderWithId,
      toastMessage,
      showToast
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
