export interface ColorVariant {
  colorHex: string;
  colorName: string;
  image?: string; // Main image for this color variant
  images?: string[]; // Multiple photos specific to this color variant
}

export interface Product {
  id: string;
  title: string;
  price: number;
  originalPrice?: number;
  stock: number;
  image: string;
  images?: string[]; // Multiple product photos
  colorVariants?: ColorVariant[]; // Color variant mapping to images
  category: string;
  brand: string;
  rating: number;
  reviewsCount: number;
  colors: string[]; // Color hex codes or color names
  availableSizes?: string[]; // Custom shoe sizes e.g. ['India 6', 'India 7', 'India 8']
  isBestSeller?: boolean;
  isNewArrival?: boolean;
  description: string;
  updatedAt?: string;
}

export interface CategoryItem {
  id: string;
  name: string;
  image: string;
  description?: string;
}

export interface SiteConfig {
  heroTitle: string;
  heroSubtitle: string;
  heroCtaText: string;
  heroImage: string;
  promoTitle: string;
  promoSubtitle: string;
  promoCtaText: string;
  promoImage: string;
  announcementText: string;
  updatedAt?: string;
}

export interface OrderItem {
  productId: string;
  title: string;
  price: number;
  quantity: number;
  selectedColor?: string;
  selectedSize?: string;
  image: string;
}

export interface Order {
  id: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  address: string;
  items: OrderItem[];
  totalAmount: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  createdAt: string;
}

export interface Enquiry {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  createdAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor: string;
  selectedSize?: string;
}

export interface NewsArticle {
  id: string;
  title: string;
  subtitle: string;
  image: string;
  category: string;
  brand: string;
  readTime: string;
}
